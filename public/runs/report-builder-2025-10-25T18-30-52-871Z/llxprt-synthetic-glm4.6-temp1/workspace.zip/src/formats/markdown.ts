import { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let output = `# ${title}

${summary}

## Entries
`;

  for (const entry of entries) {
    output += `- **${entry.label}** — $${entry.amount.toFixed(2)}
`;
  }

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `
**Total:** $${total.toFixed(2)}`;
  }

  return output;
}