#!/usr/bin/env node

import fs from 'fs';
import { ReportData, RenderOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIParsedArgs {
  dataFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CLIParsedArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    throw new Error('--format argument is required');
  }
  const format = args[formatIndex + 1] as FormatType;
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;

  const includeTotalsIndex = args.indexOf('--includeTotals');
  const includeTotals = includeTotalsIndex !== -1;

  return { dataFile, format, outputPath, includeTotals };
}

function loadData(path: string): ReportData {
  const content = fs.readFileSync(path, 'utf8');
  try {
    const data = JSON.parse(content) as ReportData;

    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }

    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" array');
    }

    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Entry missing or invalid "label" field');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Entry missing or invalid "amount" field');
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON in data file');
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: FormatType, options: RenderOptions): string {
  if (format === 'markdown') {
    return renderMarkdown(data, options);
  } else if (format === 'text') {
    return renderText(data, options);
  } else {
    throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments();
    const data = loadData(dataFile);
    const options: RenderOptions = { includeTotals };
    const output = renderReport(data, format, options);

    if (outputPath) {
      fs.writeFileSync(outputPath, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
