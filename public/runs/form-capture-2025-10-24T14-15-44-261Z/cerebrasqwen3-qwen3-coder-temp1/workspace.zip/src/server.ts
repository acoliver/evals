import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import sqlite3 from 'sql.js';
import fs from 'fs';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
let db: sqlite3.Database;

// Load or create database
function initializeDatabase() {
  try {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new sqlite3.Database(fileBuffer);
  } catch (err) {
    // If file doesn't exist, create new database
    db = new sqlite3.Database();
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
  }
}

// Save database to file
function saveDatabase() {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

// Initialize database on startup
initializeDatabase();

// GET route for form
app.get('/', (req, res) => {
  res.render('form', { errors: {}, data: {} });
});

// Validation functions
function validateRequired(value: string | undefined): boolean {
  return value !== undefined && value.trim() !== '';
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\d\s\-\+\(\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric with spaces (covers UK, Argentine and other international formats)
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// POST route for form submission
app.post('/submit', (req, res) => {
  const data: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors: FormErrors = {};

  // Validate required fields
  if (!validateRequired(data.firstName)) errors.firstName = 'First name is required';
  if (!validateRequired(data.lastName)) errors.lastName = 'Last name is required';
  if (!validateRequired(data.streetAddress)) errors.streetAddress = 'Street address is required';
  if (!validateRequired(data.city)) errors.city = 'City is required';
  if (!validateRequired(data.stateProvince)) errors.stateProvince = 'State/Province/Region is required';
  if (!validateRequired(data.postalCode)) errors.postalCode = 'Postal code is required';
  if (!validateRequired(data.country)) errors.country = 'Country is required';
  if (!validateRequired(data.email)) errors.email = 'Email is required';
  if (!validateRequired(data.phone)) errors.phone = 'Phone number is required';

  // Validate specific field formats
  if (data.email && !validateEmail(data.email)) errors.email = 'Please enter a valid email address';
  if (data.phone && !validatePhone(data.phone)) errors.phone = 'Please enter a valid phone number';
  if (data.postalCode && !validatePostalCode(data.postalCode)) errors.postalCode = 'Please enter a valid postal code';

  // If there are errors, re-render the form with errors and data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, data });
  }

  // Insert data into database
  const stmt = db.prepare(
    'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone,
  ]);
  stmt.free();

  // Save database
  saveDatabase();

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

// GET route for thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
let server: any;
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server?.close(() => {
    console.log('Server closed');
    // Save the database before closing
    saveDatabase();
    process.exit(0);
  });
});

// Start server
server = app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

export default app;