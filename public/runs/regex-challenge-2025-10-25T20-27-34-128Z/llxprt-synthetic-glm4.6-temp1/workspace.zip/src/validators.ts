export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Luhn algorithm for credit card validation
 */
function runLuhnCheck(number: string): boolean {
  const digits = number.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with comprehensive checks
 */
export function isValidEmail(value: string): boolean {
  if (!value) return false;
  
  // Basic structure check
  const emailRegex = /^([a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)@((?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})$/;
  if (!emailRegex.test(value)) return false;
  
  // Validate local part
  const localPart = value.split('@')[0];
  
  // No consecutive dots in local part
  if (localPart.includes('..')) return false;
  
  // No starting or ending dot in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Validate domain part
  const domainPart = value.split('@')[1];
  
  // No underscores in domain
  if (domainPart.includes('_')) return false;
  
  // No consecutive dots in domain
  if (domainPart.includes('..')) return false;
  
  // No starting or ending dot in domain
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) return false;
  
  return true;
}

/**
 * Validate US phone numbers with various formats
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Extract country code if present
  let actualDigits = digits;
  if (digits.length === 11 && digits.startsWith('1')) {
    actualDigits = digits.substring(1);
  } else if (digits.length > 10) {
    return false;
  }
  
  // US phone numbers must have 10 digits
  if (actualDigits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = actualDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Basic format validation
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[-\s]?)?\d{3}[-\s]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers for landlines and mobiles
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Test for formats:
  // 1. With country code: [+54][9][areaCode][subscriber]
  // 2. Without country code: [0][areaCode][subscriber]
  
  // Format with country code (+54)
  const withCountryCodeRegex = /^54(9)?([2-9]\d{1,3})(\d{6,8})$/;
  
  // Format without country code (starts with trunk prefix 0)
  const withoutCountryCodeRegex = /^0([2-9]\d{1,3})(\d{6,8})$/;
  
  const withCountryCodeMatch = digits.match(withCountryCodeRegex);
  const withoutCountryCodeMatch = digits.match(withoutCountryCodeRegex);
  
  if (!withCountryCodeMatch && !withoutCountryCodeMatch) return false;
  
  const match = withCountryCodeMatch || withoutCountryCodeMatch;
  if (!match) return false;
  const areaCodeDigits = match[2].length;
  const subscriberDigits = match[3].length;
  
  // Area code must be 2-4 digits, subscriber must be 6-8 digits
  if (areaCodeDigits < 2 || areaCodeDigits > 4) return false;
  if (subscriberDigits < 6 || subscriberDigits > 8) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim() === '') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and special symbols (except apostrophe and hyphen)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!nameRegex.test(value)) return false;
  
  // No consecutive spaces
  if (value.includes('  ')) return false;
  
  // Can't start or end with space, apostrophe, or hyphen
  if (/^[\s'\-]|[\s'\-]$/u.test(value)) return false;
  
  // Ensure contains at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx with Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Visa: 13 or 16 digits, starts with 4
  if (/^4\d{12}$|^4\d{15}$/.test(digits) && runLuhnCheck(digits)) {
    return true;
  }
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if (
    (/^5[1-5]\d{14}$/.test(digits) || /^2(2[2-9]|[3-6]\d|7[0-1])\d{12}$/.test(digits)) &&
    runLuhnCheck(digits)
  ) {
    return true;
  }
  
  // AmEx: 15 digits, starts with 34 or 37
  if (/^3[47]\d{13}$/.test(digits) && runLuhnCheck(digits)) {
    return true;
  }
  
  return false;
}
