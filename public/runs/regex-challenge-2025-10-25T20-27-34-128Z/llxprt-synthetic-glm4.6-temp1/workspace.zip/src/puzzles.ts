/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Word boundary + prefix + rest of word
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9_-]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find token following a digit, but not at start of string
  const tokenRegex = new RegExp(`(?<!^)\\d${escapedToken}\\b`, 'g');
  
  const matches = [...text.matchAll(tokenRegex)];
  
  return matches.map(match => match[0]);
}

/**
 * Validate passwords according to the policy.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  if (/(.{2}).*\1/.test(value)) return false;
  
  // Check for repeated characters
  if (/(.)\1{2,}/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First check for potential IPv4 addresses and exclude them
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value) && !/\[|\]|\:/.test(value)) {
    return false; // Pure IPv4 address, not IPv6
  }
  
  // IPv6 regex patterns
  // Full format (8 groups of 4 hex digits)
  const ipv6FullRegex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Shorthand with :: (compressed zeros)
  const ipv6CompressedRegex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv4 mapped in IPv6
  const ipv6IPv4Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // Test for IPv6 patterns
  return (
    ipv6FullRegex.test(value) ||
    ipv6CompressedRegex.test(value) ||
    ipv6IPv4Regex.test(value)
  );
}