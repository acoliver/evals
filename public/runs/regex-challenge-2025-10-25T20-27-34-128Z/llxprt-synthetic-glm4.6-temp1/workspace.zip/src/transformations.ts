/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Split by sentence punctuation (. ? !) but process the text while preserving punctuation
  const segments = text.split(/([.?!])/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < segments.length; i++) {
    const segment = segments[i];
    
    // Punctuation marks
    if (segment === '.' || segment === '?' || segment === '!') {
      result += segment;
      capitalizeNext = true;
      continue;
    }
    
    // Handle spaces
    if (segment) {
      // Collapse multiple spaces
      const cleanSegment = segment.replace(/\s+/g, ' ').trim();
      
      if (cleanSegment) {
        // Add space before this segment if needed
        if (result.length > 0 && !result.endsWith(' ') && i > 0 && segments[i-1] && segments[i-1].match(/[.?!]/)) {
          result += ' ';
        }
        
        // Capitalize if this is the start of a sentence
        if (capitalizeNext) {
          result += cleanSegment.charAt(0).toUpperCase() + cleanSegment.slice(1);
          capitalizeNext = false;
        } else {
          result += cleanSegment;
        }
      } else {
        // Keep original spacing for empty segments
        result += segment;
      }
    }
  }
  
  return result;
}

/**
 * Find URLs in the text and return them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern
  const urlPattern = /(https?:\/\/[^\s]+)/g;
  const urls: string[] = [];
  
  let match;
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?]+$/g, '');
    
    // Remove surrounding brackets or quotes
    if ((url.startsWith('(') && url.endsWith(')')) ||
        (url.startsWith('[') && url.endsWith(']')) ||
        (url.startsWith('{') && url.endsWith('}')) ||
        (url.startsWith('"') && url.endsWith('"')) ||
        (url.startsWith("'") && url.endsWith("'"))) {
      url = url.slice(1, -1);
    }
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\/([^s])/g, 'https://$1');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // Pattern to match http(s)://example.com/...
  const urlRegex = /(http(?:)?:\/\/([^\/]+)(\/.*|$))/g;
  
  return text.replace(urlRegex, (match, fullUrl, hostname, path) => {
    // Skip if path contains dynamic hints, query strings, or certain extensions
    const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // Convert scheme to https
    let rewrittenUrl = `https://${hostname}${path}`;
    
    if (!hasDynamicHint && path.startsWith('/docs/')) {
      // Change hostname to docs.example.com
      rewrittenUrl = `https://docs.${hostname}${path}`;
    } else if (!match.startsWith('https:')) {
      // Just upgrade the scheme if it's http
      rewrittenUrl = `https://${hostname}${path}`;
    }
    
    return rewrittenUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (day < 1 || day > (isLeapYear ? 29 : 28)) return 'N/A';
  } else if (day < 1 || day > maxDays[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
