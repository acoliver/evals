import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const hasPreviousPage = currentPage > 1;
  const hasNextPage = data.hasNext;

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      
      <div style={{ marginTop: '1rem' }}>
        <button 
          onClick={() => setCurrentPage(currentPage - 1)}
          disabled={!hasPreviousPage}
        >
          Previous
        </button>
        <span style={{ margin: '0 1rem' }}>
          Page {data.page} of {Math.ceil(data.total / data.limit)}
        </span>
        <button 
          onClick={() => setCurrentPage(currentPage + 1)}
          disabled={!hasNextPage}
        >
          Next
        </button>
      </div>
      
      {data.items.length === 0 && (
        <p>No inventory items found.</p>
      )}
    </section>
  );
}
