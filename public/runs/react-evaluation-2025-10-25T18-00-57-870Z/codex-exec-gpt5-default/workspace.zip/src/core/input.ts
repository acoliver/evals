/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'
import { notifyObservers, resolveEqualFn, trackDependency } from './graph.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = resolveEqualFn(equal)

  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      trackDependency(subject, observer as Observer<unknown>)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(subject.value, nextValue)) return subject.value
    subject.value = nextValue
    notifyObservers(subject)
    return subject.value
  }

  return [read, write]
}
