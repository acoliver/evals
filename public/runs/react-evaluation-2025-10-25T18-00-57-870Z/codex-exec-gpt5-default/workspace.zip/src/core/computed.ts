/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  EqualFn,
  GetterFn,
  Observer,
  Options,
  Subject,
  UpdateFn,
  getActiveObserver,
} from '../types/reactive.js'
import {
  notifyObservers,
  resolveEqualFn,
  runObserver,
  trackDependency,
} from './graph.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const equalFn = resolveEqualFn(equal)

  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
  }

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (previous) => {
      const next = updateFn(previous)
      const current = subject.value
      if (equalFn && equalFn(current, next)) {
        return current
      }
      subject.value = next
      notifyObservers(subject)
      return next
    },
  }
  runObserver(observer)

  const read: GetterFn<T> = () => {
    const active = getActiveObserver()
    if (active) {
      trackDependency(subject, active as Observer<unknown>)
    }
    return subject.value
  }

  return read
}
