/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn } from '../types/reactive.js'
import { releaseObserver, runObserver } from './graph.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }

  runObserver(observer)

  let disposed = false

  return () => {
    if (disposed) return
    disposed = true
    releaseObserver(observer)
  }
}
