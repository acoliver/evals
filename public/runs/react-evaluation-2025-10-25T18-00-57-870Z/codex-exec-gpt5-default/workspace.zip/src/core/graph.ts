import {
  EqualFn,
  Observer,
  Subject,
  updateObserver,
} from '../types/reactive.js'

type AnySubject = Subject<unknown>
type AnyObserver = Observer<unknown>

const subjectObservers = new WeakMap<AnySubject, Set<AnyObserver>>()
const observerSubjects = new WeakMap<AnyObserver, Set<AnySubject>>()

function removeObserverFromSubject(subject: AnySubject, observer: AnyObserver): void {
  const observers = subjectObservers.get(subject)
  if (!observers) return
  observers.delete(observer)
  if (!observers.size) subjectObservers.delete(subject)
}

export function trackDependency<T, U>(subject: Subject<T>, observer: Observer<U>): void {
  const subjectKey = subject as AnySubject
  const observerKey = observer as AnyObserver

  let observers = subjectObservers.get(subjectKey)
  if (!observers) {
    observers = new Set()
    subjectObservers.set(subjectKey, observers)
  }
  observers.add(observerKey)

  let subjects = observerSubjects.get(observerKey)
  if (!subjects) {
    subjects = new Set()
    observerSubjects.set(observerKey, subjects)
  }
  subjects.add(subjectKey)
}

export function releaseObserver<T>(observer: Observer<T>): void {
  const observerKey = observer as AnyObserver
  const subjects = observerSubjects.get(observerKey)
  if (!subjects) return
  for (const subject of subjects) {
    removeObserverFromSubject(subject, observerKey)
  }
  observerSubjects.delete(observerKey)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  const subjectKey = subject as AnySubject
  const observers = subjectObservers.get(subjectKey)
  if (!observers || observers.size === 0) return
  const pending = Array.from(observers)
  for (const observer of pending) {
    if (!observers.has(observer)) continue
    runObserver(observer)
  }
}

export function runObserver<T>(observer: Observer<T>): void {
  releaseObserver(observer)
  updateObserver(observer)
}

export function resolveEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (typeof equal === 'function') return equal
  if (equal === false) return undefined
  return Object.is
}
