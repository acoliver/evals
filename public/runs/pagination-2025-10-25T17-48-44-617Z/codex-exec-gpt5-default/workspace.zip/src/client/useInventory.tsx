import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number) {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();

    async function load() {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: limit.toString()
        });
        const response = await fetch(`/inventory?${params.toString()}`, {
          signal: controller.signal
        });
        const bodyText = await response.text();
        let payload: unknown = null;
        if (bodyText) {
          try {
            payload = JSON.parse(bodyText) as InventoryPage;
          } catch {
            // leave payload as null; response will be treated as malformed
          }
        }

        if (!response.ok) {
          const serverMessage =
            payload && typeof payload === 'object' && payload !== null && 'error' in payload
              ? String((payload as { error: unknown }).error)
              : `Request failed with status ${response.status}`;
          throw new Error(serverMessage);
        }

        if (!payload || typeof payload !== 'object') {
          throw new Error('Malformed server response.');
        }

        if (!cancelled) {
          setState({ status: 'ready', data: payload as InventoryPage, error: null });
        }
      } catch (error) {
        if (controller.signal.aborted) {
          return;
        }

        if (!cancelled) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    load();

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [page, limit]);

  return state;
}
