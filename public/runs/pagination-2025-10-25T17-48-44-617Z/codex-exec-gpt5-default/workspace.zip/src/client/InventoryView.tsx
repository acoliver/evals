import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [page, setPage] = useState(1);
  const { status, data, error } = useInventory(page, PAGE_LIMIT);

  const canGoPrevious = page > 1;
  const canGoNext = Boolean(data?.hasNext);

  if ((status === 'loading' || status === 'idle') && !data) {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const totalPages = Math.max(1, Math.ceil(data.total / data.limit));
  const isEmpty = data.items.length === 0;

  return (
    <section>
      <h1>Inventory</h1>
      {status === 'loading' && (
        <p aria-live="polite" role="status">
          Loading page {page}…
        </p>
      )}
      {isEmpty ? <p>No inventory available for this page.</p> : <InventoryList items={data.items} />}
      <footer>
        <div>
          <button
            type="button"
            onClick={() => setPage((current) => Math.max(1, current - 1))}
            disabled={!canGoPrevious}
            aria-label="Previous page"
          >
            Previous
          </button>
          <span>
            Page {data.page} of {totalPages}
          </span>
          <button
            type="button"
            onClick={() => setPage((current) => current + 1)}
            disabled={!canGoNext}
            aria-label="Next page"
          >
            Next
          </button>
        </div>
      </footer>
    </section>
  );
}
