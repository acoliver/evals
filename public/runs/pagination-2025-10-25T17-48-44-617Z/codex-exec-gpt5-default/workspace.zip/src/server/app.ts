import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;
const MAX_PAGE = 1000;
const MAX_LIMIT = 50;

class PaginationError extends Error {}

function coerceNumericQuery(value: unknown): number | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (Array.isArray(value)) {
    throw new PaginationError('Pagination parameters must be provided only once.');
  }

  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    throw new PaginationError('Pagination parameters must be numbers.');
  }

  return parsed;
}

function validatePositiveInt(value: number | undefined, options: { name: string; defaultValue: number; max: number }): number {
  const { name, defaultValue, max } = options;

  if (value === undefined) {
    return defaultValue;
  }

  if (!Number.isInteger(value)) {
    throw new PaginationError(`"${name}" must be an integer.`);
  }

  if (value <= 0) {
    throw new PaginationError(`"${name}" must be greater than 0.`);
  }

  if (value > max) {
    throw new PaginationError(`"${name}" is too large. Maximum allowed is ${max}.`);
  }

  return value;
}

function parsePagination(query: { page?: unknown; limit?: unknown }): { page: number; limit: number } {
  const rawPage = coerceNumericQuery(query.page);
  const rawLimit = coerceNumericQuery(query.limit);

  const page = validatePositiveInt(rawPage, { name: 'page', defaultValue: DEFAULT_PAGE, max: MAX_PAGE });
  const limit = validatePositiveInt(rawLimit, { name: 'limit', defaultValue: DEFAULT_LIMIT, max: MAX_LIMIT });

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const { page, limit } = parsePagination({ page: req.query.page, limit: req.query.limit });
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof PaginationError ? error.message : 'Invalid pagination parameters.';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
