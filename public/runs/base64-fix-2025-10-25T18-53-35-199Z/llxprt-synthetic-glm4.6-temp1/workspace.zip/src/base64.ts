/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet and padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard.
 * Accepts input with or without padding and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input cannot be empty');
  }

  // Check for valid Base64 characters only (A-Z, a-z, 0-9, +, /, =)
  const base64Pattern = /^[A-Za-z0-9+/=]+$/;
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for padding correctness - padding must be at the end and no more than 2 '=' chars
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = input.slice(paddingIndex);
    // Padding only allowed at the end
    if (padding !== '=' && padding !== '==') {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    // No non-padding characters after padding starts
    if (paddingIndex !== input.length - padding.length) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
