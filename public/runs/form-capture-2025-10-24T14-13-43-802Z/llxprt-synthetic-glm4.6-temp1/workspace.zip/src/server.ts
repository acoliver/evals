import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import process from 'process';

// SQL.js needs to be imported asynchronously
let initializeDb: () => Promise<any>;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Type definitions for our form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse request bodies
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public directory
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: any;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

async function initDatabase() {
  try {
    const sqlModule = await import('sql.js');
    const SQL = sqlModule.default;
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Check if database file exists
    let databaseExists = fs.existsSync(dbPath);
    
    if (databaseExists) {
      // Load existing database
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Read schema file and execute it
      const schemaPath = path.join(__dirname, '../db/schema.sql');
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      db.run(schemaSql);
      
      // Save the new database
      writeDatabaseToFile();
    }
    
    console.log('Database initialized successfully');
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Write database to file
function writeDatabaseToFile() {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone) && phone.length > 5;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  // Required field validation
  for (const [key, value] of Object.entries(formData)) {
    if (!value || value.trim() === '') {
      errors[key] = `${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`;
    }
  }
  
  // Email validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', async (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    const errorMessages = Object.values(validation.errors);
    return res.render('form', {
      errors: errorMessages,
      values: formData
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Write database to file
    writeDatabaseToFile();
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred saving your information. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'there';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  try {
    await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown
    const gracefulShutdown = (signal: string) => {
      console.log(`\nReceived ${signal}. Closing server gracefully...`);
      server.close(() => {
        console.log('Server closed.');
        if (db) {
          db.close();
          console.log('Database connection closed.');
        }
        process.exit(0);
      });
      
      // Force close if graceful shutdown takes too long
      setTimeout(() => {
        console.error('Forced shutdown');
        process.exit(1);
      }, 5000);
    };
    
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { startServer, app, db };
