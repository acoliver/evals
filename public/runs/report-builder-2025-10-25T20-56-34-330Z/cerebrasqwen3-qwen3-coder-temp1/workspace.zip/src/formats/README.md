# Report Formats

This directory contains modules for rendering reports in different formats.

Each format module exports a function that takes ReportData and RenderOptions and returns a formatted string.