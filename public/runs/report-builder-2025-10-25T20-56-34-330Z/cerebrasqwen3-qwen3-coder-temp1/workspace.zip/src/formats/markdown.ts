import { ReportData, RenderOptions } from '../interfaces/report.js';

export function renderMarkdown(data: ReportData, options: RenderOptions = {}): string {
  let result = `# ${data.title}\n\n${data.summary}\n\n## Entries\n`;
  
  for (const entry of data.entries) {
    result += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }
  
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `\n**Total:** $${total.toFixed(2)}\n`;
  }
  
  return result;
}