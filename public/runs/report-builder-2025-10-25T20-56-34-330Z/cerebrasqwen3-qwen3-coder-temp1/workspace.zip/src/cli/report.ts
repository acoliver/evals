#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../interfaces/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);
const filePath = args[0];

// Find the format argument
const formatIndex = args.indexOf('--format');
const format = formatIndex !== -1 ? args[formatIndex + 1] : undefined;

// Find the output argument
const outputIndex = args.indexOf('--output');
const outputPath = outputIndex !== -1 ? args[outputIndex + 1] : undefined;

// Check for includeTotals flag
const includeTotals = args.includes('--includeTotals');

// Validate required arguments
if (!filePath) {
  console.error('Error: Data file path is required');
  process.exit(1);
}

if (!format) {
  console.error('Error: Format is required');
  process.exit(1);
}

// Validate format
if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format "${format}"`);
  process.exit(1);
}

// Read and validate data
let data: ReportData;
try {
  const fileContent = readFileSync(filePath, 'utf-8');
  data = JSON.parse(fileContent) as ReportData;
  
  // Validate data structure
  if (!data.title || typeof data.title !== 'string') {
    throw new Error('Missing or invalid title');
  }
  
  if (!data.summary || typeof data.summary !== 'string') {
    throw new Error('Missing or invalid summary');
  }
  
  if (!Array.isArray(data.entries)) {
    throw new Error('Missing or invalid entries array');
  }
  
  for (const entry of data.entries) {
    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error('Missing or invalid label in entry');
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error('Missing or invalid amount in entry');
    }
  }
} catch (err) {
  console.error(`Error: Invalid JSON data - ${(err as Error).message}`);
  process.exit(1);
}

// Render based on format
let output: string;
switch (format) {
  case 'markdown':
    output = renderMarkdown(data, { includeTotals });
    break;
  case 'text':
    output = renderText(data, { includeTotals });
    break;
  default:
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
}

// Output to file or stdout
if (outputPath) {
  try {
    writeFileSync(outputPath, output, 'utf-8');
    console.log(`Report written to ${outputPath}`);
  } catch (err) {
    console.error(`Error: Failed to write to ${outputPath} - ${(err as Error).message}`);
    process.exit(1);
  }
} else {
  console.log(output);
}