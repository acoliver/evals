import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;
const MAX_PAGE = 1000;
const MAX_LIMIT = 50;

class PaginationError extends Error {
  status: number;

  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

function ensureSingleQueryValue(value: unknown, name: string): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value === 'string') {
    return value;
  }

  if (Array.isArray(value)) {
    throw new PaginationError(`${name} must be provided once`);
  }

  throw new PaginationError(`${name} must be a string value`);
}

interface NormalizedParamConfig {
  name: string;
  defaultValue: number;
  max: number;
}

function normalizePositiveInteger(value: string | undefined, config: NormalizedParamConfig): number {
  if (value === undefined) {
    return config.defaultValue;
  }

  const trimmed = value.trim();
  if (trimmed === '') {
    throw new PaginationError(`${config.name} must be an integer`);
  }

  const parsed = Number(trimmed);

  if (!Number.isFinite(parsed) || !Number.isInteger(parsed)) {
    throw new PaginationError(`${config.name} must be an integer`);
  }

  if (parsed <= 0) {
    throw new PaginationError(`${config.name} must be greater than zero`);
  }

  if (parsed > config.max) {
    throw new PaginationError(`${config.name} must be less than or equal to ${config.max}`);
  }

  return parsed;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = ensureSingleQueryValue(req.query.page, 'page');
      const limitParam = ensureSingleQueryValue(req.query.limit, 'limit');

      const page = normalizePositiveInteger(pageParam, {
        name: 'page',
        defaultValue: DEFAULT_PAGE,
        max: MAX_PAGE
      });
      const limit = normalizePositiveInteger(limitParam, {
        name: 'limit',
        defaultValue: DEFAULT_LIMIT,
        max: MAX_LIMIT
      });

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      if (error instanceof PaginationError) {
        res.status(error.status).json({ error: error.message });
        return;
      }

      res.status(500).json({ error: 'Failed to load inventory' });
    }
  });

  return app;
}
