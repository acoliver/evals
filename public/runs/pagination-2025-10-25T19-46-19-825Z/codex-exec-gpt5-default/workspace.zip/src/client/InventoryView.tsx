import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [page, setPage] = useState(1);
  const { status, data, error } = useInventory(page, PAGE_LIMIT);
  const isLoadingInitial = (status === 'loading' || status === 'idle') && !data;
  const isErrorState = status === 'error' && !data;

  if (isLoadingInitial) {
    return <p>Loading inventory…</p>;
  }

  if (isErrorState || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const isLoadingPage = status === 'loading';
  const hasItems = data.items.length > 0;
  const canGoPrevious = data.page > 1 && !isLoadingPage;
  const canGoNext = data.hasNext && !isLoadingPage;

  const goToPrevious = () => {
    if (data.page > 1) {
      setPage((prev) => Math.max(1, prev - 1));
    }
  };

  const goToNext = () => {
    if (data.hasNext) {
      setPage((prev) => prev + 1);
    }
  };

  return (
    <section>
      <h1>Inventory</h1>
      {isLoadingPage && <p aria-live="polite">Loading inventory…</p>}
      {hasItems ? <InventoryList items={data.items} /> : <p>No inventory items found.</p>}
      <footer>
        <button type="button" onClick={goToPrevious} disabled={!canGoPrevious}>
          Previous
        </button>
        <span>
          Page {data.page} of {Math.max(1, Math.ceil(data.total / data.limit))}
        </span>
        <button type="button" onClick={goToNext} disabled={!canGoNext}>
          Next
        </button>
      </footer>
    </section>
  );
}
