import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number) {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      setState((prev) => ({
        status: 'loading',
        data: prev.data,
        error: null
      }));
      try {
        const params = new URLSearchParams({
          page: String(page),
          limit: String(limit)
        });

        const response = await fetch(`/inventory?${params.toString()}`, {
          signal: controller.signal
        });

        let payload: unknown = null;

        if (!response.ok) {
          try {
            payload = await response.json();
          } catch {
            // ignore parse errors
          }
          const message =
            payload && typeof (payload as { error?: string }).error === 'string'
              ? (payload as { error: string }).error
              : `Request failed with status ${response.status}`;
          throw new Error(message);
        }

        payload = await response.json();

        if (!controller.signal.aborted) {
          setState({ status: 'ready', data: payload as InventoryPage, error: null });
        }
      } catch (error) {
        if (!controller.signal.aborted) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    load();

    return () => {
      controller.abort();
    };
  }, [page, limit]);

  return state;
}
