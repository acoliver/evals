import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [page, setPage] = useState(1);
  const { status, data, error } = useInventory(page, PAGE_LIMIT);

  if ((status === 'loading' || status === 'idle') && !data) {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const totalPages = data.total > 0 ? Math.ceil(data.total / data.limit) : 1;
  const isLoading = status === 'loading';
  const canGoPrevious = page > 1 && !isLoading;
  const canGoNext = data.hasNext && !isLoading;

  const handlePrevious = () => {
    if (page > 1) {
      setPage((current) => Math.max(1, current - 1));
    }
  };

  const handleNext = () => {
    if (data.hasNext) {
      setPage((current) => current + 1);
    }
  };

  return (
    <section>
      <h1>Inventory</h1>
      {data.items.length === 0 ? <p>No inventory to display.</p> : <InventoryList items={data.items} />}
      {isLoading ? <p aria-live="polite">Loading inventory…</p> : null}
      <nav aria-label="Inventory pagination">
        <button type="button" onClick={handlePrevious} disabled={!canGoPrevious}>
          Previous
        </button>
        <span>
          Page {data.page} of {totalPages}
        </span>
        <button type="button" onClick={handleNext} disabled={!canGoNext}>
          Next
        </button>
      </nav>
    </section>
  );
}
