import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { DEFAULT_LIMIT, listInventory } from './inventoryRepository';

const DEFAULT_PAGE = 1;
const MAX_PAGE = 1000;
const MAX_LIMIT = 100;

class PaginationValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PaginationValidationError';
  }
}

function parsePaginationParam(
  label: 'page' | 'limit',
  value: string | undefined,
  options: { defaultValue: number; min: number; max: number }
): number {
  if (value === undefined) {
    return options.defaultValue;
  }

  const numericValue = Number(value);

  if (!Number.isFinite(numericValue) || !Number.isInteger(numericValue)) {
    throw new PaginationValidationError(`Invalid "${label}": must be an integer.`);
  }

  if (numericValue < options.min) {
    throw new PaginationValidationError(`Invalid "${label}": must be at least ${options.min}.`);
  }

  if (numericValue > options.max) {
    throw new PaginationValidationError(`Invalid "${label}": must be at most ${options.max}.`);
  }

  return numericValue;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const page = parsePaginationParam('page', req.query.page as string | undefined, {
        defaultValue: DEFAULT_PAGE,
        min: 1,
        max: MAX_PAGE
      });

      const limit = parsePaginationParam('limit', req.query.limit as string | undefined, {
        defaultValue: DEFAULT_LIMIT,
        min: 1,
        max: MAX_LIMIT
      });

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      if (error instanceof PaginationValidationError) {
        res.status(400).json({ error: error.message });
        return;
      }

      res.status(500).json({ error: 'Unexpected error fetching inventory.' });
    }
  });

  return app;
}
