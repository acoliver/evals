/**
 * Encode plain text to Base64 using canonical RFC 4648 encoding.
 * Uses standard Base64 alphabet with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws an error for invalid inputs.
 */
export function decode(input: string): string {
  // Trim whitespace
  const trimmedInput = input.trim();
  
  // Validate input only contains valid Base64 characters
  const base64Pattern = /^[A-Za-z0-9+/]+={0,2}$/;
  
  if (!base64Pattern.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }
  
  try {
    // Standard Base64 decode using regular 'base64' encoding
    const result = Buffer.from(trimmedInput, 'base64').toString('utf8');
    
    // Validate that we got proper UTF-8 encoding
    // If Buffer.from with 'base64' silently fails for invalid padding, this helps catch it
    if (!result && trimmedInput.length > 0) {
      throw new Error('Invalid Base64 input: decoding failed');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
