export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface RenderOptions {
  includeTotals?: boolean;
}