import {
  EqualFn,
  Observer,
  ObserverR,
  Subject,
  updateObserver
} from '../types/reactive.js'

const SUBJECT_OBSERVERS = Symbol('reactive.subjectObservers')
const OBSERVER_SUBJECTS = Symbol('reactive.observerSubjects')
const OBSERVER_DISPOSED = Symbol('reactive.observerDisposed')

type AnyObserver = Observer<unknown>
type AnySubject = Subject<unknown>

type ObserverInternal = AnyObserver & {
  [OBSERVER_SUBJECTS]?: Set<AnySubject>
  [OBSERVER_DISPOSED]?: boolean
}

type SubjectInternal = AnySubject & {
  [SUBJECT_OBSERVERS]?: Set<ObserverInternal>
}

function getSubjectInternals<T>(subject: Subject<T>): SubjectInternal {
  return subject as SubjectInternal
}

function getObserverInternals<T>(
  observer: Observer<T> | ObserverR,
  allowDisposed = false
): ObserverInternal | undefined {
  const candidate = observer as ObserverInternal | undefined
  if (!candidate) return undefined
  if (typeof (candidate as AnyObserver).updateFn !== 'function') return undefined
  if (!allowDisposed && candidate[OBSERVER_DISPOSED]) return undefined
  return candidate
}

function ensureObserverSubjects(observer: ObserverInternal): Set<AnySubject> {
  if (!observer[OBSERVER_SUBJECTS]) {
    observer[OBSERVER_SUBJECTS] = new Set<AnySubject>()
  }
  return observer[OBSERVER_SUBJECTS]!
}

function ensureSubjectObservers(subject: SubjectInternal): Set<ObserverInternal> {
  if (!subject[SUBJECT_OBSERVERS]) {
    subject[SUBJECT_OBSERVERS] = new Set<ObserverInternal>()
  }
  return subject[SUBJECT_OBSERVERS]!
}

export function resolveEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (typeof equal === 'function') return equal
  if (equal === false) return undefined
  return (lhs: T, rhs: T) => Object.is(lhs, rhs)
}

export function registerDependency<T>(subject: Subject<T>, observer: ObserverR | undefined): void {
  if (!observer) return
  const observerInternal = getObserverInternals(observer)
  if (!observerInternal) return

  const subjectInternal = getSubjectInternals(subject)
  const observers = ensureSubjectObservers(subjectInternal)
  if (!observers.has(observerInternal)) {
    observers.add(observerInternal)
  }

  const dependencies = ensureObserverSubjects(observerInternal)
  dependencies.add(subjectInternal)

  subjectInternal.observer = observer
}

export function cleanupObserver<T>(observer: Observer<T>): void {
  const internal = getObserverInternals(observer, true)
  if (!internal) return

  const dependencies = internal[OBSERVER_SUBJECTS]
  if (!dependencies || dependencies.size === 0) return

  for (const subject of dependencies) {
    const subjectInternal = getSubjectInternals(subject)
    const observers = subjectInternal[SUBJECT_OBSERVERS]
    if (!observers) continue
    observers.delete(internal)
    if (observers.size === 0) {
      delete subjectInternal[SUBJECT_OBSERVERS]
    }
  }

  dependencies.clear()
}

export function notifyObservers<T>(subject: Subject<T>): void {
  const subjectInternal = getSubjectInternals(subject)
  const observers = subjectInternal[SUBJECT_OBSERVERS]
  if (!observers || observers.size === 0) return

  const snapshot = Array.from(observers)
  for (const observer of snapshot) {
    if (observer[OBSERVER_DISPOSED]) {
      observers.delete(observer)
      continue
    }
    updateObserver(observer as AnyObserver)
  }
}

export function disposeObserver<T>(observer: Observer<T>): boolean {
  const internal = getObserverInternals(observer)
  if (!internal || internal[OBSERVER_DISPOSED]) return false

  internal[OBSERVER_DISPOSED] = true
  cleanupObserver(observer)
  return true
}
