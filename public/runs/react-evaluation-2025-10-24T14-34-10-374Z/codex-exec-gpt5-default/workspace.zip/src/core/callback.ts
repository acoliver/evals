/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'
import { cleanupObserver, disposeObserver } from './internals.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (previousValue) => {
      cleanupObserver(observer)
      return updateFn(previousValue)
    },
  }

  updateObserver(observer)

  return () => {
    if (!disposeObserver(observer)) return

    observer.updateFn = (currentValue) => currentValue as T
  }
}
