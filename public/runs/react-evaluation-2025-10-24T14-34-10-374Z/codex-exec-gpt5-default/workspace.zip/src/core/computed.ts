/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  EqualFn,
  Subject,
  getActiveObserver,
  updateObserver
} from '../types/reactive.js'
import {
  cleanupObserver,
  notifyObservers,
  registerDependency,
  resolveEqualFn
} from './internals.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const initialValue = value !== undefined ? value : (undefined as unknown as T)
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: initialValue,
    equalFn: resolveEqualFn(_equal),
  }

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (previousValue) => {
      cleanupObserver(observer)
      const nextValue = updateFn(previousValue)
      const currentValue = subject.value
      subject.value = nextValue

      const { equalFn } = subject
      if (!equalFn || !equalFn(currentValue, nextValue)) {
        notifyObservers(subject)
      }

      return subject.value
    },
  }

  updateObserver(observer)

  return (): T => {
    const active = getActiveObserver()
    if (active) registerDependency(subject, active)
    return subject.value
  }
}
