/**
 * Report entry containing label and monetary amount
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Report data structure matching JSON schema
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Rendering options for report formatters
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Function signature for report formatters
 */
export type ReportRenderer = (
  data: ReportData,
  options: RenderOptions
) => string;