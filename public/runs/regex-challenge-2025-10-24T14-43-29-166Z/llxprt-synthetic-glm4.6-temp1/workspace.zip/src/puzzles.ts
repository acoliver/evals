/**
 * Finds words starting with a given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  // \b ensures we match whole words
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z0-9]*)\\b`, 'gi');
  
  const matches = text.match(wordPattern);
  if (!matches) {
    return [];
  }
  
  // Convert to lowercase to handle case-insensitive matching
  const prefixLower = prefix.toLowerCase();
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  
  // Filter out matches that are in the exceptions list
  const filtered = [...new Set(matches)] // Unique values
    .filter(word => {
      const wordLower = word.toLowerCase();
      
      // Check if the word starts with our prefix (case-insensitive)
      if (!wordLower.startsWith(prefixLower)) {
        return false;
      }
      
      // Check if word is in exceptions list
      return !exceptionsLower.includes(wordLower);
    });
  
  return filtered;
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token preceded by a digit, but not at start of string
  // Use capturing group to include the preceding digit
  const pattern = new RegExp(`(\\d)${escapedToken}`, 'g');
  
  const results: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Return the full match including the digit
    results.push(match[0]);
  }
  
  return results;
}

/**
 * Validates password strength according to security requirements.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This is a simplified check that looks for 2-character patterns repeated immediately
  for (let i = 0; i < value.length - 3; i++) {
    // Check for pattern of length 2 repeated immediately after itself
    const chunk1 = value.substring(i, i + 2);
    const chunk2 = value.substring(i + 2, i + 4);
    
    if (chunk1 === chunk2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses while ensuring IPv4 addresses don't trigger false positives.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // IPv6 pattern that handles:
  // - Full notation (e.g., 2001:0db8:85a3:0000:0000:8a2e:0370:7334)
  // - Shorthand with :: (e.g., 2001:db8::1)
  // - IPv6 with embedded IPv4 (e.g., ::ffff:192.168.0.1)
  
  // First, ensure it's not an IPv4 address
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Pattern.test(value)) {
    // If the entire input is just an IPv4, return false
    // But continue checking because there might be IPv6 elsewhere in the text
    const onlyIPv4 = new RegExp(`^${ipv4Pattern.source}$`);
    if (onlyIPv4.test(value.trim())) {
      return false;
    }
  }
  
  // IPv6 pattern with word boundaries to avoid matching parts of words
  // This covers the main IPv6 formats while avoiding false positives
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:?|:[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}/;
  
  return ipv6Pattern.test(value);
}