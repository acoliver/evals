export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common standards.
 * Supports '+' in local part and rejects invalid patterns like double dots.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compatible email regex focusing on common patterns
  // Allows unicode in local part, + tags, standard domains, subdomains
  // Disallows double dots, trailing dots, underscores in domain
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Parts must exist
  if (!localPart || !domain) {
    return false;
  }
  
  // No consecutive dots
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // No trailing dots
  if (localPart.endsWith('.') || domain.endsWith('.') || localPart.startsWith('.')) {
    return false;
  }
  
  // Domain must not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain must have at least one dot
  if (!domain.includes('.')) {
    return false;
  }
  
  // TLD validation (2-63 characters, all letters)
  const tld = domain.split('.').pop();
  if (!tld || !/^[a-zA-Z]{2,63}$/.test(tld)) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various common formats.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value) {
    return false;
  }
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for optional +1 prefix
  const startsWithPlus = value.startsWith('+');
  let numDigits = digits.length;
  let startIdx = 0;
  
  if (startsWithPlus && digits.startsWith('1')) {
    // +1 prefix detected
    if (digits.length === 11) {
      // Full +1.phone number
      numDigits = 10;
      startIdx = 1;
    } else if (digits.length > 11) {
      // Too many digits for a valid US phone number
      return false;
    }
  }
  
  // Check minimum length (10 digit phone number)
  if (numDigits !== 10) {
    return false;
  }
  
  // Extract area code
  const areaCode = digits.substring(startIdx, startIdx + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Additional check: area code cannot be 911
  if (areaCode === '911') {
    return false;
  }
  
  // Check for valid parentheses around area code if present
  const hasParens = value.includes('(') && value.includes(')');
  if (hasParens) {
    const parensMatch = /^\s*\+?1?\s*\((\d{3})\)/.test(value);
    if (!parensMatch) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers in international and national formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Replace all spaces, hyphens, and parentheses for parsing
  const cleaned = value.replace(/[\s\-\(\)]/g, '');
  
  // Check if country code +54 is present
  const hasCountryCode = cleaned.startsWith('+54');
  
  // Determine the base pattern to validate
  let baseNumber = cleaned;
  if (hasCountryCode) {
    baseNumber = cleaned.substring(3); // Remove '+54'
  }
  
  // If no country code, must begin with trunk prefix 0
  if (!hasCountryCode && !baseNumber.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix if present
  let afterTrunk = baseNumber;
  if (baseNumber.startsWith('0')) {
    afterTrunk = baseNumber.substring(1);
  }
  
  // Check for mobile indicator (9)
  let afterMobileIndicator = afterTrunk;
  if (afterTrunk.startsWith('9')) {
    afterMobileIndicator = afterTrunk.substring(1);
  }
  
  // Area code must be 2-4 digits, leading digit cannot be 0
  const areaCodeMatch = afterMobileIndicator.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCodeLength = areaCodeMatch[1].length;
  
  // Extract remaining number after area code
  const subscriberNumber = afterMobileIndicator.substring(areaCodeLength);
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Validate all characters are digits
  if (!/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names with unicode support.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Names should contain unicode letters, apostrophes, hyphens, spaces
  // Should not contain numbers or uncommon symbols
  
  // Basic pattern: unicode letters + apostrophes/hyphens/spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Names cannot start or end with special characters (apostrophe/hyphen/space)
  if (value.match(/^['\-\s]|['\-\s]$/)) {
    return false;
  }
  
  // Reject names that contain numbers or symbols
  if (/\d|[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (can't be just spaces/hyphens/apostrophes)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using Luhn algorithm and card format rules.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length rules for common card brands
  const length = digits.length;
  
  // Visa: 13 or 16 digits, starts with 4
  if (/^4/.test(digits) && (length === 13 || length === 16)) {
    return runLuhnCheck(digits);
  }
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if ((length === 16) && (
    /^5[1-5]/.test(digits) || 
    /^2(2[2-9]|[3-6]\d|7[01])/.test(digits)
  )) {
    return runLuhnCheck(digits);
  }
  
  // American Express: 15 digits, starts with 34 or 37
  if (length === 15 && /^3[47]/.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  return false;
}

/**
 * Helper function to perform Luhn checksum algorithm.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isSecondDigit = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isSecondDigit) {
      digit *= 2;
      
      // If result is two digits, sum them
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isSecondDigit = !isSecondDigit;
  }
  
  // Valid if sum modulo 10 is 0
  return sum % 10 === 0;
}