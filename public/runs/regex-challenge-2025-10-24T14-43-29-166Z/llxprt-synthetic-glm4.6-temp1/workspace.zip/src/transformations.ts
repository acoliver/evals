/**
 * Capitalizes the first character of each sentence while preserving other formatting.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // Trim leading and trailing whitespace to handle edge cases
  const trimmedText = text;
  
  // Pattern to match sentence endings: . ? ! followed by optional quotes and spaces
  const sentenceEndRegex = /([.?!])(?:['"')\]}\s]*)(\s*)/g;
  
  // Insert a single space after each sentence ending if not present
  const normalizedSpacing = trimmedText.replace(sentenceEndRegex, '$1 ');
  
  // Trim extra spaces to handle multiple spaces that might be created
  const resultText = normalizedSpacing.replace(/\s{2,}/g, ' ');
  
  // Trim trailing space at the end
  const finalText = resultText.replace(/\s+$/g, '');
  
  // Now capitalize first letter after start of string or sentence endings
  return finalText.replace(/(^|[.?!]\s+)([a-z])/g, (match, before, letter) => {
    return before + letter.toUpperCase();
  });
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // URL pattern that matches common URL formats
  // Captures http/https/ftp protocols, domains with optional subdomains, ports, paths, query strings, and fragments
  const urlRegex = /\b((https?|ftp):\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&//=]*))\b/gi;
  
  const matches = text.match(urlRegex);
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Strip trailing punctuation characters that aren't valid at end of URL
    return url.replace(/[.,;:!?)\]\}'"']+$/g, '');
  });
}

/**
 * Enforces HTTPS by converting all HTTP URLs to HTTPS.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https:// while leaving https:// unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs following specific rules.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // This regex pattern matches http:// URLs and captures components for rewriting
  // It handles the domain and path separately to allow for conditional rewriting
  
  return text.replace(/http:\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)/g, (match, domain, path) => {
    // First, always upgrade to HTTPS
    let newUrl = `https://${domain}${path}`;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for exceptions (dynamic hints, legacy extensions)
      const hasExceptions = /cgi-bin|\?|\&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);
      
      if (!hasExceptions) {
        // Rewrite host to docs.example.com while preserving the rest of the path
        newUrl = `https://docs.${domain}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format or returns N/A.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format
  const dateMatch = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (simplified validation, doesn't account for leap years in February)
  const daysInMonth = [
    31, // January
    28, // February (simplified, not accounting for leap years)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}