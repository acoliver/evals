import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJS, { Database } from 'sql.js';

// Initialize Express app
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initDB() {
  const SQL = await initSqlJS({
    locateFile: (file) => `node_modules/sql.js/dist/${file}`
  });

  // Load existing database or create a new one
  try {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } catch (err) {
    // Database file doesn't exist, create a new one
    db = new SQL.Database();
    const schemaSql = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schemaSql);
  }
}

// Function to save database to file
function saveDB() {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, data);
  }
}

// Validation functions
function validateRequiredField(value: string | undefined): boolean {
  return !!value && value.trim().length > 0;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\+]?[0-9\s\-\(\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings with spaces and dashes
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;

  const errors: string[] = [];

  // Validate required fields
  if (!validateRequiredField(firstName)) errors.push('First name is required');
  if (!validateRequiredField(lastName)) errors.push('Last name is required');
  if (!validateRequiredField(streetAddress)) errors.push('Street address is required');
  if (!validateRequiredField(city)) errors.push('City is required');
  if (!validateRequiredField(stateProvince)) errors.push('State / Province / Region is required');
  if (!validateRequiredField(postalCode)) errors.push('Postal code is required');
  if (!validateRequiredField(country)) errors.push('Country is required');
  if (!validateRequiredField(email)) errors.push('Email is required');
  if (!validateRequiredField(phone)) errors.push('Phone number is required');

  // Validate email format
  if (email && !validateEmail(email)) errors.push('Please provide a valid email address');

  // Validate phone format
  if (phone && !validatePhone(phone)) errors.push('Please provide a valid phone number');

  // Validate postal code format
  if (postalCode && !validatePostalCode(postalCode)) errors.push('Please provide a valid postal code');

  // If validation errors, re-render form with errors and values
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: req.body
    });
  }

  // Insert submission into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      firstName,
      lastName,
      streetAddress,
      city,
      stateProvince,
      postalCode,
      country,
      email,
      phone
    ]);
    
    saveDB();
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Initialize database and start server
initDB().then(() => {
  const server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });

  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
      saveDB();
      console.log('Server closed');
      process.exit(0);
    });
  });

  process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    server.close(() => {
      saveDB();
      console.log('Server closed');
      process.exit(0);
    });
  });
}).catch((err) => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

export default app;