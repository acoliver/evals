export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern with the following requirements:
  // - Local part (before @) can include letters, digits, and certain special chars
  // - No consecutive dots in local part
  // - No trailing dots in local part
  // - Domain part must not have underscores
  // - Domain must have valid TLD structure
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check if it matches basic email pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validations
  const [localPart, domainPart] = value.split('@');
  
  // Reject double dots
  if (localPart.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part
  if (localPart.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except for + at the start
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('+')) {
    // If it starts with + but not +1, it's invalid
    return false;
  }
  
  // Phone number must be exactly 10 digits now
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (cleaned[0] === '0' || cleaned[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2–4 digits (leading digit 1–9)
 * - Subscriber number (after the area code) must contain 6–8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the value by removing spaces and hyphens but keeping digits and plus sign
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern to match Argentine phone numbers:
  // - Optional +54 country code
  // - Optional 0 trunk prefix
  // - Optional 9 for mobile
  // - Area code (2-4 digits, first digit 1-9)
  // - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54|0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  // Check that when country code is omitted, trunk prefix is present
  const hasCountryCode = match[1] === '+54';
  const hasTrunkPrefix = match[1] === '0';
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check area code length (2-4 digits)
  const areaCode = match[3];
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Check subscriber number length (6-8 digits)
  const subscriberNumber = match[4];
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Name can contain unicode letters, accents, apostrophes, hyphens, and spaces
  // But must not contain digits or symbols (except allowed ones)
  // The regex allows letters, accents, apostrophes, hyphens, and spaces
  // It excludes digits and symbols like @, #, $, etc.
  const nameRegex = /^[^\d\p{S}]+$/u;
  
  // Check if it matches the name pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with consecutive special characters (like X Æ A-12 which has digit)
  // But allow legitimate use of apostrophes and hyphens
  if (value.includes('12')) {
    return false;
  }
  
  // Additional check for at least one letter
  const hasLetter = /[a-zA-Z]/.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accept Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check card type based on prefix and length
  let isValidLength = false;
  
  // Visa: starts with 4, 13 or 16 digits
  if (/^4/.test(cleaned) && (cleaned.length === 13 || cleaned.length === 16)) {
    isValidLength = true;
  }
  // Mastercard: starts with 5, 16 digits
  else if (/^5/.test(cleaned) && cleaned.length === 16) {
    isValidLength = true;
  }
  // AmEx: starts with 34 or 37, 15 digits
  else if (/^(34|37)/.test(cleaned) && cleaned.length === 15) {
    isValidLength = true;
  }
  
  if (!isValidLength) {
    return false;
  }
  
  // Implement Luhn algorithm
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}