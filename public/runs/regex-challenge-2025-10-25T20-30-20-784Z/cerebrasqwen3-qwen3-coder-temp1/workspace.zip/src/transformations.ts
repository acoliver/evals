/**
 * Capitalizes the first character of each sentence.
 * Preserves spacing rules and handles abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence-ending punctuation followed by whitespace or end of string
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
}

/**
 * Extracts URLs from text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // This pattern matches URLs starting with http:// or https://
  // It now correctly includes the full domain portion of the URL
  const urlRegex = /https?:\/\/[^\s,.;:!?)\]}]+(?:\.[^\s,.;:!?)\]}]+)*/gi;
  const matches = text.match(urlRegex);
  return matches ? matches : [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all instances of 'http://' with 'https://' 
  // but only when not already 'https://'
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skips host rewrite when path contains dynamic hints.
 */
export function rewriteDocsUrls(text: string): string {
  // Regex pattern to match URLs with http:// scheme and example.com host
  // Also checks if path starts with /docs/ and doesn't contain dynamic elements
  return text.replace(/http:\/\/(example\.com)(\/docs\/[^\s,.;:!?)\]}]*)/gi, (match, host, path) => {
    // Check if path contains dynamic hints
    const hasDynamicHints = /[?&=]|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    // Always upgrade to https
    let result = `https://${host}${path}`;
    
    // Rewrite host only when path starts with /docs/ and has no dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      result = result.replace(host, 'docs.example.com');
    }
    
    return result;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}