#!/usr/bin/env node

// TODO: implement the report CLI as described in problem.md
console.error('report CLI not implemented');
process.exit(1);
