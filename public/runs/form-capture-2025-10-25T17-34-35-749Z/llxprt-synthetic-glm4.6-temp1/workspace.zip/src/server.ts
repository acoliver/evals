import express, { Express, Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
// @ts-expect-error: sql.js doesn't have proper type definitions
import initSqlJs from 'sql.js';

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface FormErrors {
  [key: string]: string;
}

const app: Express = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
let db: unknown = null;

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

function validateForm(data: FormData): FormErrors {
  const errors: FormErrors = {};
  
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal code is required';
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.postalCode = 'Postal code contains invalid characters';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Email is not valid';
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.phone = 'Phone number contains invalid characters';
  }
  
  return errors;
}

async function initializeDatabase(): Promise<unknown> {
  try {
    const dataDir = path.join(__dirname, '..', 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const dbPath = path.join(dataDir, 'submissions.sqlite');
    let dbBuffer: Uint8Array;
    
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(fileBuffer);
    } else {
      dbBuffer = new Uint8Array(0);
    }
    
    const SQL = await initSqlJs();
    const database = new SQL.Database(dbBuffer);
    
    const schema = fs.readFileSync(
      path.join(__dirname, '..', 'db', 'schema.sql'),
      'utf-8'
    );
    database.run(schema);
    
    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(db: unknown): void {
  try {
    const database = db as { export: () => Uint8Array };
    const data = database.export();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

app.get('/', (req: Request, res: Response) => {
  const errors = req.query.errors as string[] | undefined;
  res.render('form', { 
    errors: errors || [],
    values: {} as FormData
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = req.body;
  const errors = validateForm(formData);
  
  if (Object.keys(errors).length > 0) {
    const errorMessages = Object.values(errors);
    return res.render('form', {
      errors: errorMessages,
      values: formData
    });
  }
  
  if (!db) {
    return res.status(500).send('Database not initialized');
  }
  
  try {
    const database = db as { 
      prepare: (sql: string) => { 
        run: (params: unknown[]) => void; 
        free: () => void; 
      }
    };
    
    const stmt = database.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase(db);
    
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).send('Failed to save submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}, shutting down gracefully`);
  
  if (db) {
    try {
      saveDatabase(db);
      const database = db as { close: () => void };
      database.close();
      db = null;
      console.log('Database closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

async function startServer(): Promise<void> {
  try {
    db = await initializeDatabase();
    console.log('Database initialized');
    
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  startServer().catch((error) => {
    console.error('Unhandled error:', error);
    process.exit(1);
  });
}

export { app, initializeDatabase, gracefulShutdown };