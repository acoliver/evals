/**
 * Encode plain text to Base64 using the standard RFC 4648 alphabet.
 * @param input - The UTF-8 string to encode
 * @returns The Base64 encoded string with proper padding
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * @param input - The Base64 string to decode
 * @returns The decoded UTF-8 string
 * @throws {Error} If the input is not valid Base64
 */
export function decode(input: string): string {
  // Check if the input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}