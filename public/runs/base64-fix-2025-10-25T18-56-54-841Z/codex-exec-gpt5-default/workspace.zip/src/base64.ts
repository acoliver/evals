const BASE64_BODY = /^[A-Za-z0-9+/=]*$/;

/**
 * Encode plain text to canonical RFC 4648 Base64 (with padding).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

function normalizeBase64(input: string): string {
  const stripped = input.replace(/\s+/g, '');

  if (!stripped) {
    throw new Error('Empty Base64 input');
  }

  if (!BASE64_BODY.test(stripped)) {
    throw new Error('Invalid Base64 input');
  }

  const firstPad = stripped.indexOf('=');
  if (firstPad !== -1) {
    const paddingSection = stripped.slice(firstPad);
    if (!/^=+$/.test(paddingSection) || paddingSection.length > 2) {
      throw new Error('Invalid Base64 padding');
    }
  }

  let normalized = stripped;
  const remainder = normalized.length % 4;
  if (remainder === 1) {
    throw new Error('Invalid Base64 length');
  }

  if (remainder > 0) {
    if (firstPad !== -1) {
      throw new Error('Invalid Base64 padding');
    }
    normalized += '='.repeat(4 - remainder);
  }

  return normalized;
}

/**
 * Decode Base64 text back to plain UTF-8.
 */
export function decode(input: string): string {
  const normalized = normalizeBase64(input);
  const buffer = Buffer.from(normalized, 'base64');
  const reencoded = buffer.toString('base64');

  if (reencoded !== normalized) {
    throw new Error('Invalid Base64 input');
  }

  return buffer.toString('utf8');
}
