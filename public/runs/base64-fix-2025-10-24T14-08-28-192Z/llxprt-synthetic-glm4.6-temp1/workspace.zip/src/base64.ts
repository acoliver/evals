/**
 * Encode plain text to Base64 using standard RFC 4648 format.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard RFC 4648 format.
 * Accepts valid Base64 with or without padding, throws an error for invalid input.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Normalize padding if needed (Buffer will handle missing padding correctly)
  const normalizedInput = input.trim();
  
  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
