/**
 * Capitalizes the first character of each sentence (after .?!), 
 * inserts exactly one space between sentences even if the input omitted it,
 * and collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Step 1: Replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ');

  // Step 2: Ensure there's exactly one space after sentence-ending punctuation
  // This handles cases where there might be no space or multiple spaces
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');

  // Step 3: Trim spaces at the beginning and end
  result = result.trim();

  // Step 4: Capitalize the first letter of each sentence
  // Use negative lookbehind to find the first letter after sentence-ending punctuation or string start
  result = result.replace(/(?:^|[.!?]\s+)([a-z])/g, (match, letter, _offset, _fullString) => {
    return match.slice(0, -1) + letter.toUpperCase();
  });

  return result;
}

/**
 * Extracts all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // Regex to match URLs with http://, https://, or www. prefix
  // Negative lookbehind ensures we don't capture punctuation at the end
  const urlRegex = /(?:https?:\/\/|www\.)[^\s/$.?#].[^\s]*?(?=[,.!?;:)]?(?:\s|$))/g;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }

  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[,.!?;:)]+$/, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Replace http:// with https://, but don't affect https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to these rules:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when the path contains dynamic hints (cgi-bin, query string ?, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Regex to match URLs with capture groups
  // Group 1: protocol (http:// or https://)
  // Group 2: host (example.com)
  // Group 3: path (everything after the domain, optional)
  const urlRegex = /((?:https?):\/\/)([^\/\s]+)(\/[^\s]*)?/g;

  return text.replace(urlRegex, (match, protocol, host, path = '') => {
    // Always upgrade to https first
    const newProtocol = 'https://';

    // If no path or path doesn't start with /docs/, just upgrade the protocol
    if (!path || !path.startsWith('/docs/')) {
      return `${newProtocol}${host}${path}`;
    }

    // Check if the path contains dynamic hints (cgi-bin, query strings, legacy extensions)
    const hasDynamicHints = /(?:\b(cgi-bin)\b|[\?&]|\.(?:jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$))/i.test(path);

    // If dynamic hints are present, only upgrade the scheme
    if (hasDynamicHints) {
      return `${newProtocol}${host}${path}`;
    }

    // Otherwise, rewrite the host to docs.example.com
    return `${newProtocol}docs.example.com${path}`;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Regex to match mm/dd/yyyy format and capture month, day, and year
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }

  // Additional validation for days based on month
  const daysInMonth = [
    31, // January
    (parseInt(year, 10) % 4 === 0 && (parseInt(year, 10) % 100 !== 0 || parseInt(year, 10) % 400 === 0)) ? 29 : 28, // February (leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];

  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}
