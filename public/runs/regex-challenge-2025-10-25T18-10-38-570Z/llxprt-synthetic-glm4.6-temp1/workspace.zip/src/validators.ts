export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for common patterns like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domain underscores, and other invalid formats.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check - one @, no whitespace
  if (!value || value.includes(' ') || value.split('@').length !== 2) {
    return false;
  }

  const [localPart, domain] = value.split('@');

  // Local part validation (allowed: letters, digits, ., _, +, -, with constraints)
  // Local part must not start or end with dot and no consecutive dots
  const localRegex = /^[a-zA-Z0-9._%+-]+$/;
  if (!localRegex.test(localPart) || 
      localPart.startsWith('.') || 
      localPart.endsWith('.') || 
      localPart.includes('..')) {
    return false;
  }

  // Domain validation
  // Domain cannot have underscores, must have at least one dot, no consecutive dots, and proper structure
  const domainRegex = /^[a-zA-Z0-9.-]+$/;
  if (!domainRegex.test(domain) || 
      domain.includes('_') || 
      !domain.includes('.') || 
      domain.startsWith('-') || 
      domain.endsWith('-') ||
      domain.includes('..')) {
    return false;
  }

  // Split domain into labels
  const domainParts = domain.split('.');
  // Must have at least 2 parts (e.g., example.com)
  if (domainParts.length < 2) {
    return false;
  }

  // Validate each domain label
  for (const part of domainParts) {
    // Each part must not start or end with hyphen, and be at least 1 character
    if (part.startsWith('-') || part.endsWith('-') || part.length === 0) {
      return false;
    }
  }

  // TLD must be at least 2 characters and contain only letters
  const tld = domainParts[domainParts.length - 1];
  const tldRegex = /^[a-zA-Z]{2,}$/;
  if (!tldRegex.test(tld)) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers with support for common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, and optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');

  // Handle optional +1 country code
  let phoneNumber;
  if (digits.startsWith('1') && digits.length === 11) {
    phoneNumber = digits.substring(1); // Remove the leading 1
  } else if (digits.length === 10) {
    phoneNumber = digits;
  } else {
    // Wrong length
    return false;
  }

  // Area code must not start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Validate the original format with regex
  const usPhoneRegex = /^\+?1?\s*\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers with support for:
 * +54 9 11 1234 5678 (mobile)
 * 011 1234 5678 (landline)
 * +54 341 123 4567 (landline)
 * 0341 4234567 (landline)
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must start with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all separators (spaces, hyphens) but keep all digits
  const digitsOnly = value.replace(/[\s-]/g, '');

  // Regex for Argentine phone numbers
  // Capture groups:
  // 1. Optional country code (+54)
  // 2. Optional trunk prefix (0)
  // 3. Optional mobile indicator (9)
  // 4. Area code (2-4 digits, not starting with 0)
  // 5. Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = digitsOnly.match(argentinePhoneRegex);

  if (!match) {
    return false;
  }

  const [, countryCode, trunkPrefix] = match;

  // If country code is missing, trunk prefix is required
  if (!countryCode && !trunkPrefix) {
    return false;
  }

  // Area code must be 2-4 digits (already enforced by regex)
  // Subscriber number must be 6-8 digits (already enforced by regex)
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like "X Æ A-12" that contain digits only symbols.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Check for digits (should not have digits in a valid name)
  if (/\d/.test(value)) {
    return false;
  }

  // Allow only:
  // - Unicode letters (including accented letters)
  // - Apostrophes
  // - Hyphens
  // - Spaces
  // Names like "X Æ A-12" should fail because they contain digits
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  const hasAtLeastOneLetter = /[\p{L}\p{M}]/u.test(value);

  return nameRegex.test(value) && hasAtLeastOneLetter;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks both the format (prefix and length) and runs a Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and other non-digit characters
  const digitsOnly = value.replace(/\D/g, '');

  // Check for digits only
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }

  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(\d{3,6})?$/;
  if (visaRegex.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  if (mastercardRegex.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }

  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }

  return false;
}

/**
 * Helper function to run the Luhn checksum algorithm on a credit card number.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}
