/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string' || !Array.isArray(exceptions)) {
    return [];
  }

  // Ensure exceptions are all lowercase for case-insensitive comparison
  const lowerCaseExceptions = exceptions.map(word => word.toLowerCase());

  // Create a regex to match words starting with the prefix
  // \b matches word boundaries
  // [a-zA-Z]+ matches one or more letters
  // i flag for case-insensitive matching
  const prefixedWordRegex = new RegExp(`\\b(${prefix}[a-zA-Z]*)\\b`, 'gi');
  
  const matches = text.match(prefixedWordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches
    .map(word => word.toLowerCase()) // Normalize to lowercase for comparison
    .filter(word => !lowerCaseExceptions.includes(word))
    .map(word => word.toLowerCase()); // Return consistent lowercase
}

/**
 * Finds occurrences of a token when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookbehind to find tokens preceded by a digit, but not at the start of the string
  // (?<=\d) is a positive lookbehind for a digit
  // \b ensures we match the whole token, not within another word
  const embeddedTokenRegex = new RegExp(`(?<=\\d)${escapedToken}\\b`, 'g');
  
  const matches = text.match(embeddedTokenRegex) || [];
  
  // To include the digit in the result, we'll rebuild the full matches
  const result: string[] = [];
  if (matches.length > 0) {
    const fullMatchRegex = new RegExp(`(\\d)${escapedToken}\\b`, 'g');
    let fullMatch;
    while ((fullMatch = fullMatchRegex.exec(text)) !== null) {
      result.push(fullMatch[0]);
    }
  }
  
  return [...new Set(result)]; // Return unique results
}

/**
 * Validates passwords according to these rules:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Check length requirement
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, 1212, xyxy, etc.)
  for (let i = 0; i < value.length - 3; i++) {
    const twoCharSequence = value.substring(i, i + 2);
    const nextTwoChars = value.substring(i + 2, i + 4);
    
    if (twoCharSequence === nextTwoChars) {
      return false;
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv6 patterns to match:
  // 1. Full IPv6 with 8 groups of 1-4 hex digits separated by colons
  // 2. IPv6 with :: shorthand
  
  // Full IPv6 pattern
  const fullIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/i;
  
  // IPv6 with :: shorthand (including multiple :: patterns at different positions)
  const shorthandIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){0,7}:[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{0,4}){0,7}\b/i;

  // Check if the text contains any IPv6 patterns
  return fullIPv6Regex.test(value) || shorthandIPv6Regex.test(value);
}