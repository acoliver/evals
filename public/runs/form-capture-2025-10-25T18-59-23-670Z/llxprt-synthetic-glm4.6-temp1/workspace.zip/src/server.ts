import express from 'express';
import path from 'path';
import { promises as fs } from 'fs';
import { Response, Request } from 'express';

// type definition for sql.js
type Database = any;

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface FormErrors {
  [fieldName: string]: string;
}

function sanitizeString(str: string): string {
  // Basic sanitization: remove HTML tags and special characters
  return str.trim().replace(/<[^>]*>/g, '');
}

// Validation functions
function validateEmail(email: string | undefined): boolean {
  if (!email) return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string | undefined): boolean {
  if (!phone) return false;
  const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string | undefined): boolean {
  if (!postalCode) return false;
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

function validateRequiredField(value: string | undefined): boolean {
  return value !== undefined && value !== null && value.trim() !== '';
}

function validateForm(formData: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  if (!validateRequiredField(formData.firstName)) {
    errors.firstName = 'First name is required';
  }

  if (!validateRequiredField(formData.lastName)) {
    errors.lastName = 'Last name is required';
  }

  if (!validateRequiredField(formData.streetAddress)) {
    errors.streetAddress = 'Street address is required';
  }

  if (!validateRequiredField(formData.city)) {
    errors.city = 'City is required';
  }

  if (!validateRequiredField(formData.stateProvince)) {
    errors.stateProvince = 'State / Province / Region is required';
  }

  if (!validateRequiredField(formData.postalCode)) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Postal code must contain only letters, numbers, spaces, or hyphens';
  }

  if (!validateRequiredField(formData.country)) {
    errors.country = 'Country is required';
  }

  if (!validateRequiredField(formData.email)) {
    errors.email = 'Email is required';
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!validateRequiredField(formData.phone)) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

async function initializeDatabase(dbPath: string): Promise<Database> {
  try {
    // Try to load existing database
    const dbData = await fs.readFile(dbPath);
    return new Database(dbData);
  } catch (error) {
    // If file doesn't exist, create a new database
    const db = new Database();
    // Read schema from file
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schemaSQL = await fs.readFile(schemaPath, 'utf8');
    db.run(schemaSQL);
    return db;
  }
}

async function saveDatabase(db: Database, dbPath: string): Promise<void> {
  const dbData = db.export();
  await fs.writeFile(dbPath, Buffer.from(dbData));
}

async function createServer(): Promise<express.Application> {
  const app = express();
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  
  // Initialize database
  const db = await initializeDatabase(dbPath);

  // Static files
  app.use('/public', express.static(path.join(__dirname, '../public')));
  
  // Body parsing middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  // Routes
  app.get('/', (req, res) => {
    const errors: string[] = [];
    const values: FormData = {};

    res.render('form', { errors, values });
  });

  app.post('/submit', (req, res) => {
    const formData = req.body as FormData;
    const validation = validateForm(formData);

    if (!validation.isValid) {
      // Convert errors object to string array for template
      const errorMessages = Object.values(validation.errors);
      return res.status(400).render('form', { 
        errors: errorMessages, 
        values: formData 
      });
    }

    try {
      // Insert sanitized data into database
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        sanitizeString(formData.firstName || ''),
        sanitizeString(formData.lastName || ''),
        sanitizeString(formData.streetAddress || ''),
        sanitizeString(formData.city || ''),
        sanitizeString(formData.stateProvince || ''),
        sanitizeString(formData.postalCode || ''),
        sanitizeString(formData.country || ''),
        sanitizeString(formData.email || ''),
        sanitizeString(formData.phone || '')
      ]);

      stmt.free();

      // Save database to disk
      saveDatabase(db, dbPath)
        .then(() => {
          // Redirect to thank you page with firstName parameter
          res.redirect(302, `/thank-you?firstName=${encodeURIComponent(sanitizeString(formData.firstName || ''))}`);
        })
        .catch((error) => {
          console.error('Error saving database:', error);
          // Still redirect if database save fails
          res.redirect(302, '/thank-you');
        });
    } catch (error) {
      console.error('Error submitting form:', error);
      res.status(500).render('form', {
        errors: ['An unexpected error occurred. Please try again.'],
        values: formData
      });
    }
  });

  app.get('/thank-you', (req, res) => {
    // Extract first name from query parameter if available
    const firstName = typeof req.query.firstName === 'string' ? sanitizeString(req.query.firstName) : 'friend';
    res.render('thank-you', { firstName });
  });

  return app;
}

// Set up EJS
const __dirname = path.dirname(new URL(import.meta.url).pathname);
const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

async function startServer() {
  try {
    const serverApp = await createServer();
    const port = process.env.PORT || 3000;
    
    const server = serverApp.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

export { startServer };
export default startServer();