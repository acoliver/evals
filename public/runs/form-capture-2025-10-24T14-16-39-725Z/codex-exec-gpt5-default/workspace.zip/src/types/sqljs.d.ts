declare module 'sql.js' {
  export type SqlValue = string | number | Uint8Array | null;

  export interface QueryExecResult {
    columns: string[];
    values: SqlValue[][];
  }

  export interface Statement {
    run(params?: SqlValue[] | Record<string, SqlValue>): Statement;
    free(): void;
  }

  export class Database {
    constructor(data?: Uint8Array);
    run(sql: string): Database;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlJsStatic {
    Database: typeof Database;
  }

  export default function initSqlJs(config?: {
    locateFile?: (fileName: string) => string;
  }): Promise<SqlJsStatic>;
}
