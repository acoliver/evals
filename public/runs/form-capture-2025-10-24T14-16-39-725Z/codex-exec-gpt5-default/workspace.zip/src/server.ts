import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { promises as fs } from 'node:fs';
import { existsSync } from 'node:fs';
import initSqlJs, { Database, SqlJsStatic } from 'sql.js';

type SubmissionField =
  | 'firstName'
  | 'lastName'
  | 'streetAddress'
  | 'city'
  | 'stateProvince'
  | 'postalCode'
  | 'country'
  | 'email'
  | 'phone';

type SubmissionValues = Record<SubmissionField, string>;

interface ServerContext {
  app: express.Application;
  database: Database;
  sql: SqlJsStatic;
  persist: () => Promise<void>;
  close: () => Promise<void>;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');
const dataDir = path.resolve(projectRoot, 'data');
const dbFilePath = path.resolve(dataDir, 'submissions.sqlite');
const schemaPath = path.resolve(projectRoot, 'db', 'schema.sql');

const defaultValues: SubmissionValues = {
  firstName: '',
  lastName: '',
  streetAddress: '',
  city: '',
  stateProvince: '',
  postalCode: '',
  country: '',
  email: '',
  phone: '',
};

async function fileExists(target: string): Promise<boolean> {
  try {
    await fs.access(target);
    return true;
  } catch {
    return false;
  }
}

async function loadSql(): Promise<SqlJsStatic> {
  const wasmDir = path.resolve(projectRoot, 'node_modules', 'sql.js', 'dist');
  return initSqlJs({
    locateFile: (fileName: string) => path.resolve(wasmDir, fileName),
  });
}

async function readSchema(): Promise<string> {
  return fs.readFile(schemaPath, 'utf8');
}

async function initializeDatabase(sql: SqlJsStatic): Promise<Database> {
  if (!existsSync(dataDir)) {
    await fs.mkdir(dataDir, { recursive: true });
  }

  const schema = await readSchema();
  const db = (await fileExists(dbFilePath))
    ? new sql.Database(await fs.readFile(dbFilePath))
    : new sql.Database();

  db.exec(schema);

  if (!(await fileExists(dbFilePath))) {
    await persistDatabase(db);
  }

  return db;
}

async function persistDatabase(db: Database): Promise<void> {
  const bytes = db.export();
  const buffer = Buffer.from(bytes);
  await fs.writeFile(dbFilePath, buffer);
}

function trimValues(input: Partial<Record<string, string>>): SubmissionValues {
  const values: SubmissionValues = { ...defaultValues };
  (Object.keys(values) as SubmissionField[]).forEach((key) => {
    const rawValue = input[key];
    values[key] = typeof rawValue === 'string' ? rawValue.trim() : '';
  });
  return values;
}

function validate(values: SubmissionValues): string[] {
  const errors: string[] = [];

  (Object.keys(values) as SubmissionField[]).forEach((key) => {
    if (!values[key]) {
      const readable = key
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, (char) => char.toUpperCase());
      errors.push(`${readable} is required.`);
    }
  });

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (values.email && !emailPattern.test(values.email)) {
    errors.push('Email must look like a valid address.');
  }

  const phonePattern = /^\+?[0-9\s\-()]+$/;
  if (values.phone && !phonePattern.test(values.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and an optional leading +.');
  }

  const postalPattern = /^[A-Za-z0-9][A-Za-z0-9\s-]*$/;
  if (values.postalCode && !postalPattern.test(values.postalCode)) {
    errors.push('Postal / Zip code must contain letters, numbers, spaces, or dashes only.');
  }

  return errors;
}

async function insertSubmission(db: Database, values: SubmissionValues): Promise<void> {
  const statement = db.prepare(
    `INSERT INTO submissions (
      first_name,
      last_name,
      street_address,
      city,
      state_province,
      postal_code,
      country,
      email,
      phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );

  try {
    statement.run([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone,
    ]);
  } finally {
    statement.free();
  }
}

async function createServer(): Promise<ServerContext> {
  const sql = await loadSql();
  const database = await initializeDatabase(sql);
  const app = express();

  app.set('view engine', 'ejs');
  app.set('views', path.resolve(projectRoot, 'src', 'templates'));

  app.use('/public', express.static(path.resolve(projectRoot, 'public')));
  app.use(express.urlencoded({ extended: true }));

  app.get('/', (_req: Request, res: Response) => {
    res.render('form', { errors: [], values: defaultValues });
  });

  app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const values = trimValues(req.body as Record<string, string>);
      const errors = validate(values);

      if (errors.length > 0) {
        res.status(400).render('form', { errors, values });
        return;
      }

      await insertSubmission(database, values);
      await persistDatabase(database);

      const redirectUrl = `/thank-you?firstName=${encodeURIComponent(values.firstName)}`;
      res.redirect(302, redirectUrl);
    } catch (error) {
      next(error);
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const firstNameRaw = req.query.firstName;
    const firstName =
      typeof firstNameRaw === 'string' && firstNameRaw.trim().length > 0 ? firstNameRaw.trim() : 'friend';
    res.render('thank-you', { firstName });
  });

  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    void _next;
    // eslint-disable-next-line no-console
    console.error(err);
    res.status(500).send('Something went wrong. Please try again later.');
  });

  const persist = async () => persistDatabase(database);
  const close = async () => {
    await persist();
    database.close();
  };

  return { app, database, sql, persist, close };
}

async function bootstrap() {
  const { app, close } = await createServer();
  const port = Number.parseInt(process.env.PORT ?? '3000', 10) || 3000;
  const server = app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`Friendly form server listening on port ${port}`);
  });

  const shutdown = () => {
    // eslint-disable-next-line no-console
    console.log('Received shutdown signal. Closing the server gracefully...');
    server.close(async (closeError?: Error) => {
      if (closeError) {
        // eslint-disable-next-line no-console
        console.error('Error closing the HTTP server:', closeError);
      }
      try {
        await close();
        process.exit(0);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error('Error while closing resources:', error);
        process.exit(1);
      }
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

const mainModuleUrl = pathToFileURL(process.argv[1] ?? '').href;
const isMain = import.meta.url === mainModuleUrl;

if (isMain) {
  void bootstrap();
}

export { createServer, SubmissionValues, validate };
