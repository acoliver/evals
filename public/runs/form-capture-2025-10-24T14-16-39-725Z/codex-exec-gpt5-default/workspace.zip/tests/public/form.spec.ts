import { beforeAll, afterAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from '../../src/server';

const dbPath = path.resolve('data', 'submissions.sqlite');

let context: Awaited<ReturnType<typeof createServer>>;

beforeAll(async () => {
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  context = await createServer();
});

afterAll(async () => {
  if (context) {
    await context.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(context.app).get('/');
    expect(response.status).toBe(200);

    const $ = load(response.text);
    const fields = [
      'firstName',
      'lastName',
      'streetAddress',
      'city',
      'stateProvince',
      'postalCode',
      'country',
      'email',
      'phone',
    ];

    fields.forEach((name) => {
      expect($(`input[name="${name}"]`)).toHaveLength(1);
    });
  });

  it('persists submission and redirects', async () => {
    context.database.run('DELETE FROM submissions');
    await context.persist();

    const submission = {
      firstName: 'Ada',
      lastName: 'Lovelace',
      streetAddress: '27 Algorithm Ave',
      city: 'London',
      stateProvince: 'Greater London',
      postalCode: 'SW1A 1AA',
      country: 'UK',
      email: 'ada@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(context.app).post('/submit').type('form').send(submission);

    expect(response.status).toBe(302);
    expect(response.header.location).toContain('/thank-you?firstName=Ada');
    expect(fs.existsSync(dbPath)).toBe(true);

    const result = context.database.exec(
      "SELECT first_name, email FROM submissions WHERE email = 'ada@example.com'"
    );
    expect(result).toHaveLength(1);
    const storedRow = result[0]?.values[0];
    expect(storedRow).toEqual(['Ada', 'ada@example.com']);
  });
});
