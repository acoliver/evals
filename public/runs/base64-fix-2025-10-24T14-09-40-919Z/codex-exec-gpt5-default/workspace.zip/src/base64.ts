const BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;
const PADDING_STRIP_REGEX = /=+$/;

function padBase64(value: string): string {
  const remainder = value.length % 4;
  if (remainder === 0) {
    return value;
  }

  return `${value}${'='.repeat(4 - remainder)}`;
}

/**
 * Encode plain text to Base64 using the canonical alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (trimmed === '') {
    return '';
  }

  if (!BASE64_PATTERN.test(trimmed) || trimmed.length % 4 === 1) {
    throw new Error('Failed to decode Base64 input');
  }

  const padded = padBase64(trimmed);
  const buffer = Buffer.from(padded, 'base64');

  const canonical = buffer.toString('base64').replace(PADDING_STRIP_REGEX, '');
  const normalizedInput = padded.replace(PADDING_STRIP_REGEX, '');

  if (canonical !== normalizedInput) {
    throw new Error('Failed to decode Base64 input');
  }

  return buffer.toString('utf8');
}
