import { createInput, createComputed } from './src/index.ts'

console.log('Testing complex dependencies...')

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => {
  const result = input() * 2
  console.log('timesTwo computed:', result)
  return result
})

console.log('Initial timesTwo:', timesTwo())

const timesThirty = createComputed(() => {
  const result = input() * 30
  console.log('timesThirty computed:', result) 
  return result
})

console.log('Initial timesThirty:', timesThirty())

const sum = createComputed(() => {
  const t2 = timesTwo()
  const t30 = timesThirty()
  const result = t2 + t30
  console.log('sum computed:', result, '(t2:', t2, 't30:', t30, ')')
  return result
})

console.log('Initial sum:', sum())

console.log('\nSetting input to 3...')
setInput(3)
console.log('Input after set:', input())
console.log('TimesTwo after input change:', timesTwo())
console.log('TimesThirty after input change:', timesThirty())
console.log('Sum after input change:', sum())