// Simple test to verify our reactive system works

// Import directly from TypeScript files using tsx
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('Testing Reactive System - Step by Step')

// Test 1: Basic input
console.log('\n--- Test 1: Basic Input ---')
const [input, setInput] = createInput(1)
console.log('Initial input value:', input())

// Test 2: Computed values
console.log('\n--- Test 2: Computed Values ---')
const timesTwo = createComputed(() => input() * 2)
console.log('Initial timesTwo value:', timesTwo())

// Test setting input
console.log('Setting input to 3')
setInput(3)
console.log('Input after set:', input())
console.log('TimesTwo after input change:', timesTwo())

// Test 3: More complex dependencies
console.log('\n--- Test 3: Complex Dependencies ---')
const [input2, setInput2] = createInput(1)
const timesThirty = createComputed(() => input2() * 30)
const sum = createComputed(() => {
  const t2 = timesTwo()
  const t30 = timesThirty()
  return t2 + t30
})

console.log('Initial sum:', sum())
console.log('Setting input2 to 3')
setInput2(3)
console.log('Sum after change:', sum())

// Test 4: Callbacks
console.log('\n--- Test 4: Callbacks ---')
const [input3, setInput3] = createInput(1)
const output = createComputed(() => input3() + 1)
let callbackValue = 0
const unsubscribe = createCallback(() => {
  callbackValue = output()
  console.log('Callback triggered, callbackValue is now:', callbackValue)
})

console.log('Initial output:', output())
console.log('Initial callbackValue:', callbackValue)
console.log('Setting input3 to 3')
setInput3(3)
console.log('Output after input3 change:', output())
console.log('CallbackValue after input3 change:', callbackValue)