// Debug test for computed values
import { createComputed } from './src/index.ts'

console.log('Testing computed with initial value...')

const computed = createComputed(x => {
  console.log('Update function called with x:', x)
  return x * 2
}, 3)

console.log('Computed value:', computed())