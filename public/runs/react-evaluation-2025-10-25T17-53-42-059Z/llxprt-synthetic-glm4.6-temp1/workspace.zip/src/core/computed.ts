/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  registerDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const initialized = false
  
  const memoizedValue: T | undefined = undefined
  
  function recompute(): void {
    updateObserver(o)
    memoizedValue = o.value
  }
  
  return () => {
    // When the computed value is accessed, we track dependencies
    const observer = getActiveObserver()
    if (observer && observer.updateFn) {
      // Register this computed observer as a dependency for the current observer
      registerDependency(observer as Observer<T>, o)
    }
    
    // Always recompute to ensure we have the latest values
    recompute()
    
    return memoizedValue!
  }
}