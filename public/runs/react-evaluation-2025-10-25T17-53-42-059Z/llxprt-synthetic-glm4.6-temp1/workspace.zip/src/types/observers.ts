/**
 * Enhanced observer pattern implementation for reactive system
 */

export type EnhancedObserver<T> = {
  name?: string
  value?: T
  updateFn: (value?: T) => T
  dependencies: EnhancedObserver<unknown>[]
  dirty: boolean
}

export type EnhancedSubject<T> = {
  name?: string
  value: T
  equalFn?: (lhs: T, rhs: T) => boolean
  observers: Set<EnhancedObserver<T>>
}

// Global tracking of current observer being evaluated
let currentObserver: EnhancedObserver<any> | undefined = undefined

export function getCurrentObserver(): EnhancedObserver<any> | undefined {
  return currentObserver
}

export function setCurrentObserver(observer: EnhancedObserver<any> | undefined): void {
  currentObserver = observer
}

// Register dependency between observers
export function addDependency<T>(observer: EnhancedObserver<T>, dependency: EnhancedObserver<unknown>): void {
  if (!observer.dependencies.includes(dependency)) {
    observer.dependencies.push(dependency)
  }
}

// Mark an observer as dirty and propagate to dependents
export function markDirty<T>(observer: EnhancedObserver<T>): void {
  observer.dirty = true
  
  // Propagate dirtiness to all dependents
  for (const dependent of getDependents(observer)) {
    markDirty(dependent)
  }
}

// Find all observers that depend on a given observer
const registry = new WeakMap<EnhancedObserver<any>, Set<EnhancedObserver<any>>>()

export function registerDependent<T>(observer: EnhancedObserver<T>, dependent: EnhancedObserver<any>): void {
  if (!registry.has(observer)) {
    registry.set(observer, new Set())
  }
  registry.get(observer)!.add(dependent)
}

export function getDependents<T>(observer: EnhancedObserver<T>): Set<EnhancedObserver<any>> {
  return registry.get(observer) || new Set()
}

// Update an observer if it's dirty
export function updateIfDirty<T>(observer: EnhancedObserver<T>): T {
  if (observer.dirty) {
    // Update all dependencies first
    for (const dep of observer.dependencies) {
      updateIfDirty(dep)
    }
    
    // Now update this observer
    const previous = setCurrentObserver(observer)
    try {
      observer.value = observer.updateFn(observer.value)
    } finally {
      setCurrentObserver(previous)
    }
    
    observer.dirty = false
  }
  
  return observer.value!
}