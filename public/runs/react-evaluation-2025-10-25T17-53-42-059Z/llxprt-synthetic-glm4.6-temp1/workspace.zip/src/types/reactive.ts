/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Observer registry for tracking dependencies
const observerRegistry = new Set<Observer<any>>()
const dependencyMap = new WeakMap<Observer<any>, Set<Observer<any>>>()

// Register a dependency from a dependent observer to a source observer
export function registerDependency<T>(dependent: Observer<T>, source: Observer<any>): void {
  // Store the dependency so that when the source updates, we can update the dependent
  if (!dependencyMap.has(source)) {
    dependencyMap.set(source, new Set())
  }
  dependencyMap.get(source)!.add(dependent)
  
  // For debugging purposes, also store reverse dependencies
  ;(source as any).dependents = (source as any).dependents || new Set()
  ;(source as any).dependents.add(dependent)
}

// Update a source observer and all its dependents
export function updateObserverAndDependents<T>(observer: Observer<T>): void {
  const alreadyUpdated = new Set<Observer<any>>()
  
  function update(o: Observer<any>): void {
    if (alreadyUpdated.has(o)) return
    alreadyUpdated.add(o)
    
    updateObserver(o)
    
    // Check for dependents in the dependency map
    const dependents = dependencyMap.get(o)
    if (dependents) {
      dependents.forEach(dependent => update(dependent))
    }
  }
  
  update(observer)
}

// Helper function to update a subject and notify its observers
export function updateSubject<T>(subject: Subject<T>): void {
  if (subject.observer) {
    updateObserverAndDependents(subject.observer as Observer<T>)
  }
}
