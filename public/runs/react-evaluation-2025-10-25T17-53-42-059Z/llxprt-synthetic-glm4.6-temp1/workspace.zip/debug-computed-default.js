// Debug test for computed values with default parameter
import { createComputed } from './src/index.ts'

console.log('Testing computed with initial value...')

const computed = createComputed((x) => {
  if (x === undefined) {
    x = 3
  }
  console.log('Update function called with x:', x)
  return x * 2
})

console.log('Computed value:', computed())