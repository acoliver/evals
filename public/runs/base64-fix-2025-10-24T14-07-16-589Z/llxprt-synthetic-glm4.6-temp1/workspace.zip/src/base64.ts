/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Pad the string if necessary (required for Node.js Buffer API)
  const normalized = input.trim();
  let paddedInput = normalized;
  const padLength = normalized.length % 4;
  if (padLength !== 0) {
    paddedInput += '='.repeat(4 - padLength);
  }

  try {
    const result = Buffer.from(paddedInput, 'base64').toString('utf8');
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
