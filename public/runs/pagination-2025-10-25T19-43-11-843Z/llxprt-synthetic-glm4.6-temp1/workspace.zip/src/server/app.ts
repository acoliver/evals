import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: express.Request, res: express.Response) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Validate query parameters are numeric
      if (pageParam !== undefined && (isNaN(Number(pageParam)) || Number(pageParam) < 1)) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      
      if (limitParam !== undefined && (isNaN(Number(limitParam)) || Number(limitParam) < 1)) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      
      // Set reasonable maximums to prevent abuse
      const page = pageParam ? Number(pageParam) : 1;
      const limit = limitParam ? Math.min(Number(limitParam), 100) : 5;

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      if (error instanceof Error) {
        return res.status(400).json({ error: error.message });
      }
      return res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
