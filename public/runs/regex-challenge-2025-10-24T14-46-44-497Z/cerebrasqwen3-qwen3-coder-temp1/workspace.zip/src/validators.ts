export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email validation regex with additional checks
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check basic format
  if (!emailRegex.test(value)) return false;
  
  // Additional checks:
  // 1. No double dots
  if (value.includes('..')) return false;
  
  // 2. No leading or trailing dots in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.') || 
      domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // 3. No underscores in domain part
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting formats like (212) 555-7890, 212-555-7890, 2125557890
 * with optional +1 prefix. Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for length check and area code validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it has the right number of digits (10 or 11 with +1)
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  // Valid US phone number regex that allows common separators
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s\-]?\d{3}[\s\-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number (after the area code) must contain 6-8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check patterns
  const patterns = [
    // +54 9 11 1234 5678 (mobile with country code)
    /^\+54\s?9\s?[1-9]\d{1,3}\s?\d{3,4}\s?\d{4}$/,
    // +54 341 123 4567 (landline with country code)
    /^\+54\s?[1-9]\d{1,3}\s?\d{3}\s?\d{4}$/,
    // 011 1234 5678 (landline with trunk prefix)
    /^0\s?[1-9]\d{1,3}\s?\d{3,4}\s?\d{4}$|^[1-9]\d{1,3}\s?\d{3,4}\s?\d{4}$/,
    // 0341 4234567 (landline with trunk prefix, no spaces in subscriber number)
    /^0\s?[1-9]\d{1,3}[\s\-]?\d{6,8}$|^[1-9]\d{1,3}[\s\-]?\d{6,8}$/
  ];
  
  // Check if any pattern matches
  if (!patterns.some(pattern => pattern.test(value))) {
    return false;
  }
  
  // Extract the parts to validate area code and subscriber number
  let cleanValue = value.replace(/[^\d]/g, '');
  
  // If it starts with 54 (country code), remove it
  if (cleanValue.startsWith('54')) {
    cleanValue = cleanValue.substring(2);
  }
  
  // If it starts with 0 (trunk prefix), remove it
  if (cleanValue.startsWith('0')) {
    cleanValue = cleanValue.substring(1);
  }
  
  // If mobile indicator '9' is present, remove it
  if (cleanValue.startsWith('9')) {
    cleanValue = cleanValue.substring(1);
  }
  
  // Check if area code is 2-4 digits with leading digit 1-9
  const areaCodeMatch = cleanValue.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = cleanValue.substring(areaCode.length);
  
  // Check area code length
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Check subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols (except apostrophes and hyphens)
  const nameRegex = /^[^\d\p{S}]*$/u;
  
  // Additional check for X Æ A-12 style names (must not contain digits)
  if (!nameRegex.test(value) || /\d/.test(value)) return false;
  
  // Must contain at least one letter
  if (!/[^\s\-'’]/.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Supports Visa, Mastercard, and AmEx.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s\-]/g, '');
  
  // Visa: starts with 4, 13 or 16 digits
  // Mastercard: starts with 5, 16 digits
  // AmEx: starts with 34 or 37, 15 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^5\d{15}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

/**
 * Implements the Luhn algorithm for credit card validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
