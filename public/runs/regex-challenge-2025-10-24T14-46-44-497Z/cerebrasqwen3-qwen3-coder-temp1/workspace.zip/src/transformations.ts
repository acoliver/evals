/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences even if the input omitted it.
 * Collapses extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Split by sentence ending punctuation followed by whitespace or end of string
  // Use a regex that preserves abbreviations (single capital letter followed by dot)
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  }).replace(/\s+/g, ' ').trim();
}

/**
 * Finds URLs in the text. Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Match URLs (simplified pattern for common URLs)
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*[^\s.,;!?)]/gi;
  const matches = text.match(urlRegex);
  
  return matches ? [...new Set(matches)] : []; // Remove duplicates
}

/**
 * Forces all HTTP URLs to HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https:// (except when already https://)
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites HTTP URLs to HTTPS and moves docs paths to docs.example.com when applicable.
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Match http://example.com/... URLs
  // Skip rewriting when path contains dynamic elements
  return text.replace(/http:\/\/([a-zA-Z0-9\-\.]+)(\/[^\s]*)/g, (match, host, path) => {
    // Check if path contains dynamic hints
    const hasDynamicHints = /cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|\?|&|=/.test(path);
    
    // Convert to https
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite to docs.example.com
      return `https://docs.${host}${path}`;
    } else {
      // Just upgrade to https
      return `https://${host}${path}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy date format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  return year;
}
