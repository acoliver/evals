/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return '';
  }

  const normalized = text.replace(/\s+/g, ' ').replace(/\s+([.!?])/g, '$1').trim();
  if (!normalized) {
    return '';
  }

  const abbreviationSpans: Array<{ start: number; end: number }> = [];
  const abbreviationRegex = /((?:[\p{L}]\.){2,})/gu;
  let abbrMatch: RegExpExecArray | null;
  while ((abbrMatch = abbreviationRegex.exec(normalized)) !== null) {
    abbreviationSpans.push({ start: abbrMatch.index, end: abbrMatch.index + abbrMatch[0].length });
  }

  const isInsideAbbreviation = (index: number): boolean =>
    abbreviationSpans.some((span) => index >= span.start && index < span.end);

  let result = '';
  let capitalizeNext = true;
  let pendingSentenceSpace = false;
  let lastWasSpace = false;

  for (let i = 0; i < normalized.length; i += 1) {
    const char = normalized[i];

    if (char === ' ') {
      if (!lastWasSpace) {
        result += ' ';
        lastWasSpace = true;
      }
      continue;
    }
    lastWasSpace = false;

    if ('.?!'.includes(char) && !isInsideAbbreviation(i)) {
      result = result.trimEnd();
      result += char;
      capitalizeNext = true;
      pendingSentenceSpace = true;
      continue;
    }

    if (pendingSentenceSpace) {
      if (result.length > 0 && result[result.length - 1] !== ' ') {
        result += ' ';
      }
      pendingSentenceSpace = false;
    }

    if (capitalizeNext && /\p{L}/u.test(char)) {
      result += char.toUpperCase();
      capitalizeNext = false;
      continue;
    }

    result += char;
    if (/\p{L}/u.test(char)) {
      capitalizeNext = false;
    }
  }

  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"')]+/gi;
  const trailingPunctuation = /[\])}>.,!?;:'"]+$/;
  const matches: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    url = url.replace(trailingPunctuation, '');
    matches.push(url);
  }

  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return '';
  }

  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return '';
  }

  const docsRegex = /http:\/\/example\.com(?::\d+)?[^\s<>"')]+/gi;
  const trailingPunctuation = /[\])}>.,!?;:'"]+$/;

  return text.replace(docsRegex, (rawMatch) => {
    let url = rawMatch;
    const trailingMatch = url.match(trailingPunctuation);
    let punctuationSuffix = '';
    if (trailingMatch) {
      punctuationSuffix = trailingMatch[0];
      url = url.slice(0, -punctuationSuffix.length);
    }

    let parsed: URL;
    try {
      parsed = new URL(url);
    } catch {
      return rawMatch;
    }

    const lowerPath = parsed.pathname.toLowerCase();
    const hasDynamicIndicators =
      lowerPath.includes('cgi-bin') ||
      /\.(?:jsp|php|asp|aspx|do|cgi|pl|py)(?:$|[/?])/i.test(parsed.pathname) ||
      /[?&=]/.test(url);

    const shouldRewriteHost =
      lowerPath.startsWith('/docs/') && !hasDynamicIndicators && parsed.search === '';

    const portSuffix = parsed.port ? `:${parsed.port}` : '';
    const host = shouldRewriteHost ? `docs.example.com${portSuffix}` : parsed.host;
    const rebuilt = `https://${host}${parsed.pathname}${parsed.search}${parsed.hash}`;
    return `${rebuilt}${punctuationSuffix}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  const match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value.trim());
  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, yearStr] = match;
  const month = Number(monthStr);
  const day = Number(dayStr);
  const year = Number(yearStr);

  if (Number.isNaN(month) || Number.isNaN(day) || Number.isNaN(year)) {
    return 'N/A';
  }

  if (month < 1 || month > 12) {
    return 'N/A';
  }

  const daysInMonth = getDaysInMonth(month, year);
  if (day < 1 || day > daysInMonth) {
    return 'N/A';
  }

  return yearStr;
}

function getDaysInMonth(month: number, year: number): number {
  const thirtyOneDayMonths = new Set([1, 3, 5, 7, 8, 10, 12]);
  if (thirtyOneDayMonths.has(month)) {
    return 31;
  }
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    return isLeapYear ? 29 : 28;
  }
  return 30;
}
