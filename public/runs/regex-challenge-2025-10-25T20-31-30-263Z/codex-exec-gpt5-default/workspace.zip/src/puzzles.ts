/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  const escapedPrefix = escapeForRegex(prefix);
  const regex = new RegExp(`\\b${escapedPrefix}[\\p{L}0-9_'’\\-]*`, 'giu');
  const exceptionSet = new Set(exceptions.map((item) => item.toLowerCase()));
  const matches: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    const word = match[0];
    if (!exceptionSet.has(word.toLowerCase())) {
      matches.push(word);
    }
  }

  return matches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  const escapedToken = escapeForRegex(token);
  const regex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  const matches: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    const startIndex = match.index - 1;
    if (startIndex <= 0) {
      continue;
    }
    const endIndex = match.index + token.length;
    matches.push(text.slice(startIndex, endIndex));
  }

  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }

  if (/\s/.test(value)) {
    return false;
  }

  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);

  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }

  if (/(.{2,})\1/.test(value)) {
    return false;
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  const h16 = '[0-9A-Fa-f]{1,4}';
  const ipv4Octet = '(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)';
  const ipv4Address = `(?:${ipv4Octet}\\.){3}${ipv4Octet}`;
  const ipv6Core = [
    `(?:${h16}:){7}${h16}`,
    `(?:${h16}:){1,7}:`,
    `(?:${h16}:){1,6}:${h16}`,
    `(?:${h16}:){1,5}(?::${h16}){1,2}`,
    `(?:${h16}:){1,4}(?::${h16}){1,3}`,
    `(?:${h16}:){1,3}(?::${h16}){1,4}`,
    `(?:${h16}:){1,2}(?::${h16}){1,5}`,
    `${h16}:(?:(?::${h16}){1,6})`,
    `:(?:(?::${h16}){1,7}|:)`,
    `(?:${h16}:){1,4}:${ipv4Address}`,
    `::(?:ffff(?::0{1,4}){0,1}:)?${ipv4Address}`
  ].join('|');

  const ipv6Regex = new RegExp(`(?:^|[^0-9A-Fa-f:])(?:${ipv6Core})(?=$|[^0-9A-Fa-f:])`, 'i');
  return ipv6Regex.test(value);
}

function escapeForRegex(token: string): string {
  return token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
