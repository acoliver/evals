export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value) {
    return false;
  }
  const candidate = value.trim();
  if (!candidate) {
    return false;
  }

  const emailRegex =
    /^(?!.*\.\.)[a-z0-9]+(?:[._%+-][a-z0-9]+)*@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/i;
  return emailRegex.test(candidate);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value) {
    return false;
  }

  let candidate = value.trim();
  if (!candidate) {
    return false;
  }

  const extensionRegex = /\s*(?:ext(?:ension)?\.?|x)\s*\d+$/i;
  if (extensionRegex.test(candidate)) {
    if (!options?.allowExtensions) {
      return false;
    }
    candidate = candidate.replace(extensionRegex, '').trim();
  }

  const phoneRegex =
    /^\s*(?:\+?1[\s.-]*)?(?:\(([2-9]\d{2})\)|([2-9]\d{2}))[\s.-]*(\d{3})[\s.-]*(\d{4})\s*$/;
  const match = candidate.match(phoneRegex);
  if (!match) {
    return false;
  }

  const area = match[1] ?? match[2];
  return typeof area === 'string' && /^[2-9]\d{2}$/.test(area);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) {
    return false;
  }

  const stripped = value.replace(/[\s\-().]/g, '').trim();
  if (!stripped) {
    return false;
  }

  if (!/^\+?\d+$/.test(stripped)) {
    return false;
  }

  const pattern =
    /^(?<country>\+54)?(?<trunk>0)?(?<mobile>9)?(?<area>[1-9]\d{1,3})(?<subscriber>\d{6,8})$/;
  const match = stripped.match(pattern);

  if (!match?.groups) {
    return false;
  }

  const groups = match.groups as {
    country?: string;
    trunk?: string;
    subscriber: string;
  };
  const { country, trunk, subscriber } = groups;

  if (!country && trunk !== '0') {
    return false;
  }

  return subscriber.length >= 6 && subscriber.length <= 8;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value) {
    return false;
  }

  const candidate = value.trim();
  if (!candidate) {
    return false;
  }

  const unit = "[\\p{L}\\p{M}]+(?:['\u2019-][\\p{L}\\p{M}]+)*";
  const nameRegex = new RegExp(`^(?:${unit})(?:\\s+${unit})*$`, 'u');
  return nameRegex.test(candidate);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) {
    return false;
  }

  const digits = value.replace(/[\s-]/g, '');
  if (!/^\d{13,19}$/.test(digits)) {
    return false;
  }

  const length = digits.length;
  const firstTwo = parseInt(digits.slice(0, 2), 10);
  const firstFour = parseInt(digits.slice(0, 4), 10);

  const isVisa = digits.startsWith('4') && (length === 13 || length === 16 || length === 19);
  const isMastercard =
    length === 16 &&
    ((firstTwo >= 51 && firstTwo <= 55) || (firstFour >= 2221 && firstFour <= 2720));
  const isAmex = length === 15 && (digits.startsWith('34') || digits.startsWith('37'));

  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }

  return runLuhnCheck(digits);
}

function runLuhnCheck(payload: string): boolean {
  let sum = 0;
  let doubleDigit = false;

  for (let i = payload.length - 1; i >= 0; i -= 1) {
    let digit = Number(payload[i]);
    if (Number.isNaN(digit)) {
      return false;
    }
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
    doubleDigit = !doubleDigit;
  }

  return sum % 10 === 0;
}
