#!/usr/bin/env node

import fs from 'fs';

import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command line arguments
 */
function parseArguments(): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} | null {
  const args = process.argv.slice(2);
  
  // Check if we have at least a data file and format
  if (args.length < 2 || !args.includes('--format')) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    return null;
  }
  
  // Get the data path (first argument that doesn't start with --)
  const dataPathIndex = args.findIndex(arg => !arg.startsWith('--'));
  if (dataPathIndex === -1) {
    console.error('Error: Missing data file path');
    return null;
  }
  
  const dataPath = args[dataPathIndex];
  
  // Find the format
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: Missing format option');
    return null;
  }
  
  const format = args[formatIndex + 1];
  
  // Check for output path
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

/**
 * Validate and parse the JSON data
 */
function loadData(dataPath: string): ReportData {
  if (!fs.existsSync(dataPath)) {
    throw new Error(`Error: Data file not found: ${dataPath}`);
  }
  
  try {
    const fileContent = fs.readFileSync(dataPath, 'utf8');
    const data = JSON.parse(fileContent);
    
    // Validate the data structure
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: "title" must be a string');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: "summary" must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: "entries" must be an array');
    }
    
    // Validate each entry
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Invalid data: each entry must have a "label" string');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid data: each entry must have an "amount" number');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Error parsing JSON: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Get the formatter function for the requested format
 */
function getFormatter(format: string): ReportFormatter {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}. Supported formats: markdown, text`);
  }
}

/**
 * Write output to file or stdout
 */
function writeOutput(output: string, outputPath?: string): void {
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output);
      console.error(`Report written to ${outputPath}`);
    } catch (error) {
      throw new Error(`Error writing to output file: ${error}`);
    }
  } else {
    console.log(output);
  }
}

/**
 * Main entry point
 */
function main(): void {
  try {
    const args = parseArguments();
    if (!args) {
      process.exit(1);
    }
    
    const data = loadData(args.dataPath);
    const formatter = getFormatter(args.format);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    const output = formatter(data, options);
    writeOutput(output, args.outputPath);
    process.exit(0);
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
}

// Run the CLI if this file is executed directly (ES modules environment)
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}