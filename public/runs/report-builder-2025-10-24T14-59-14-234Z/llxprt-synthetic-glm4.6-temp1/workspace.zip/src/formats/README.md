Add format implementations here (e.g., markdown.ts, text.ts) exporting a shared interface for the CLI to consume.
