import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';

/**
 * Formats an amount as a currency string with two decimal places
 */
const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

/**
 * Calculate the total of all entry amounts
 */
const calculateTotal = (entries: ReportData['entries']): number => {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
};

/**
 * Renders report data in plain text format
 */
export const renderText: ReportFormatter = (
  data: ReportData,
  options: ReportOptions
): string => {
  const output: string[] = [];

  // Title
  output.push(data.title);
  output.push('');

  // Summary
  output.push(data.summary);
  output.push('');

  // Entries section
  output.push('Entries:');
  output.push('');

  // List each entry as a text bullet
  for (const entry of data.entries) {
    output.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Add total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    output.push('');
    output.push(`Total: ${formatAmount(total)}`);
  }

  return output.join('\n');
};