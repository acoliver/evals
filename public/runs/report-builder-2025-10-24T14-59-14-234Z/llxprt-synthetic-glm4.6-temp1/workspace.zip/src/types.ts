/**
 * Data structure for report entries
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Structure for the report data from JSON
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report formatting
 */
export interface ReportOptions {
  includeTotals: boolean;
}

/**
 * Formatter function interface
 */
export type ReportFormatter = (data: ReportData, options: ReportOptions) => string;