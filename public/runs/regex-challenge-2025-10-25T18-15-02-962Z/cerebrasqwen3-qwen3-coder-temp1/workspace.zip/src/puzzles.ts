/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }

  // Create a regex that matches words starting with the prefix
  // Uses word boundaries to ensure we match complete words
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(regex);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions (case insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }

  // Create a regex that finds occurrences of the token after a digit
  // Uses positive lookbehind to ensure it's preceded by a digit
  // Uses negative lookahead to ensure it's not at the start of the string
  const regex = new RegExp(`(?<=\\d)${token}`, 'gi');
  const matches = text.match(regex);
  
  return matches || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for required character types
  if (!/[a-z]/.test(value) ||    // Lowercase
      !/[A-Z]/.test(value) ||    // Uppercase
      !/\d/.test(value) ||       // Digit
      !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {  // Symbol
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab)
  // This regex looks for any sequence of 2 or more characters that immediately repeats
  if (/(\w{2,})\1/.test(value)) {
    return false;
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv6 regex patterns:
  // Full form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // With :: shorthand: various forms like xxxx::xxxx, ::xxxx, xxxx::, etc.
  // IPv4 embedded in IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:d.d.d.d
  
  // Patterns that should NOT match (IPv4):
  // d.d.d.d format
  
  // This complex regex matches valid IPv6 addresses including those with ::
  // but excludes IPv4 addresses
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/;
  
  // IPv4 regex pattern
  const ipv4Regex = /(\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it matches IPv4, return false
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // If it matches IPv6, return true
  return ipv6Regex.test(value);
}
