/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Split text into sentences using punctuation marks (.?!), preserving the punctuation
  // This regex looks for punctuation followed by whitespace or end of string
  const sentences = text.split(/(?<=[.?!])\s+/);
  
  // Capitalize the first letter of each sentence
  return sentences
    .map(sentence => {
      // Trim leading/trailing whitespace and capitalize the first character
      sentence = sentence.trim();
      if (sentence.length === 0) return sentence;
      
      // Capitalize first character
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    })
    .join(' '); // Join with a single space between sentences
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // This regex matches URLs starting with http:// or https://
  // It allows for various characters in the URL but excludes trailing punctuation
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*[^\s.,;:!?()[\]{}<>"]/gi;
  const matches = text.match(urlRegex);
  
  // Remove trailing punctuation that might have been captured
  return matches ? matches.map(url => url.replace(/[.,;:!?()[\]{}<>"]+$/, '')) : [];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Replace all instances of 'http://' with 'https://'
  // Only replace if it's not already 'https://'
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Matches URLs starting with 'http://', followed by a domain, and then a path
  // Skips rewriting host when path contains dynamic elements
  return text.replace(/http:\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)/gi, (match, domain, path) => {
    // Check if path contains dynamic hints
    const hasDynamicHints = /cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|\?|&|=/i.test(path);
    
    // Upgrade scheme to https
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      return `https://docs.${domain}${path}`;
    } else {
      // Just upgrade scheme
      return `https://${domain}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Match dates in mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Basic validation of month and day
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}
