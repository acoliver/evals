export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check if value is a string and not empty
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Email regex pattern:
  // - Local part (before @) can contain alphanumeric chars, dots, hyphens, and plus signs
  // - Must not start or end with dot, and must not contain double dots
  // - Domain part (after @) can contain alphanumeric chars, dots, and hyphens
  // - Must not start or end with hyphen or dot
  // - Must not contain underscores in domain
  // - Top-level domain must be at least 2 characters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9.+_-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
  
  // Additional checks:
  // - No double dots
  // - No trailing dots in local part
  // - No underscores in domain part
  if (!emailRegex.test(value) || 
      value.includes('..') || 
      value.endsWith('.') || 
      value.includes('@_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters for length and area code checks
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it starts with +1 and remove it for further validation
  let cleanDigits = digitsOnly;
  if (digitsOnly.startsWith('1') && digitsOnly.length > 10) {
    cleanDigits = digitsOnly.substring(1);
  }
  
  // Must have exactly 10 digits now
  if (cleanDigits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = cleanDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Valid formats:
  // (212) 555-7890
  // 212-555-7890
  // 2125557890
  const formats = [
    /^\(\d{3}\) \d{3}-\d{4}$/,       // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,          // 212-555-7890
    /^\d{10}$/,                     // 2125557890
    /^\+1 \(\d{3}\) \d{3}-\d{4}$/,  // +1 (212) 555-7890
    /^\+1 \d{3}-\d{3}-\d{4}$/,      // +1 212-555-7890
    /^\+1\d{10}$/                   // +12125557890
  ];
  
  return formats.some(format => format.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Normalize the input: remove all non-digit characters except +
  const normalized = value.replace(/[^\d+]/g, '');
  
  // Check for valid country code prefix
  let digits;
  if (normalized.startsWith('+54')) {
    digits = normalized.substring(3);
  } else if (normalized.startsWith('0')) {
    digits = normalized.substring(1);
  } else {
    return false; // Must start with +54 or 0
  }
  
  // Check area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = digits.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const remainingDigits = digits.substring(areaCode.length);
  
  // Check subscriber number (6-8 digits total)
  if (remainingDigits.length < 6 || remainingDigits.length > 8) {
    return false;
  }
  
  // Check if all remaining characters are digits
  if (!/^\d+$/.test(remainingDigits)) {
    return false;
  }
  
  // Valid formats (after normalization):
  // +54 9 11 1234 5678 (mobile)
  // 011 1234 5678 (landline with trunk prefix)
  // +54 341 123 4567 (landline)
  // 0341 4234567 (landline with trunk prefix)
  const formats = [
    /^\+54\s9\s\d{2,4}\s\d{4}\s\d{4}$/, // Mobile with country code
    /^\+54\s\d{2,4}\s\d{3}\s\d{4}$/,    // Landline with country code
    /^0\d{2,4}\s\d{4}\s\d{4}$/,         // Mobile with trunk prefix
    /^0\d{2,4}\s\d{3,4}\d{4}$/,         // Landline with trunk prefix
    /^\+54\d{6,8}$/,                    // All digits with country code
    /^0\d{8,10}$/                       // All digits with trunk prefix
  ];
  
  return formats.some(format => format.test(value));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Check if the name contains only allowed characters:
  // - Unicode letters (including accented characters)
  // - Spaces, apostrophes, and hyphens
  // - No digits or other symbols
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u1E00-\u1EFF\s'-]+$/;
  
  // Check if it contains digits or symbols like in "X Æ A-12"
  const invalidRegex = /[\d_~`!@#$%^&*()+=\[\]{}\\|;:"<>,.?\/]/;
  
  if (!nameRegex.test(value) || invalidRegex.test(value)) {
    return false;
  }
  
  // Must not be empty after trimming
  return value.trim().length > 0;
}

/**
 * Helper function to run Luhn algorithm check on credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check for valid prefixes and lengths:
  // Visa: Starts with 4, length 13 or 16
  // Mastercard: Starts with 5, length 16
  // AmEx: Starts with 34 or 37, length 15
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;          // 13 or 16 digits
  const mastercardRegex = /^5[0-9]{15}$/;                  // 16 digits
  const amexRegex = /^3[47][0-9]{13}$/;                    // 15 digits
  
  if (!(visaRegex.test(cleanValue) || 
        mastercardRegex.test(cleanValue) || 
        amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanValue);
}
