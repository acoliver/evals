const BASE64_ALLOWED = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text using the canonical RFC 4648 Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to UTF-8, validating the payload before decoding.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  const padded = padBase64(trimmed);

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

function isValidBase64(value: string): boolean {
  if (value === '') {
    return true;
  }

  if (!BASE64_ALLOWED.test(value)) {
    return false;
  }

  const paddingCount = value.length - value.replace(/=/g, '').length;

  if (paddingCount > 0 && value.length % 4 !== 0) {
    return false;
  }

  // Raw Base64 without padding cannot leave a single dangling character.
  return value.length % 4 !== 1;
}

function padBase64(value: string): string {
  const remainder = value.length % 4;
  if (remainder === 0) {
    return value;
  }

  return `${value}${'='.repeat(4 - remainder)}`;
}
