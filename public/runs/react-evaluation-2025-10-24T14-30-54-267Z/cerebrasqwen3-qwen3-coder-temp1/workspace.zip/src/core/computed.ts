/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // If equal is a boolean, use it to determine whether to use strict equality
  const equalFn = (typeof equal === 'function') 
    ? equal 
    : (equal === true) ? (lhs: T, rhs: T) => lhs === rhs : undefined;
  
  // Track all observers that depend on this computed
  const observers = new Set<Observer<unknown>>();
  
  // Create observer with compatible UpdateFn type
  const o: Observer<unknown> = {
    name: options?.name,
    value,
    // Type assertion to make updateFn compatible
    updateFn: ((prevValue?: T) => {
      // Track dependencies during computation
      const previousObserver = getActiveObserver();
      setActiveObserver(o);
      
      try {
        // Cast prevValue to T | undefined to satisfy the updateFn signature
        const newValue = updateFn(prevValue as T | undefined);
        
        // Only update if the new value is different from previous (if equalFn is provided)
        if (!equalFn || !equalFn(o.value as T, newValue)) {
          o.value = newValue;
        }
        
        return o.value;
      } finally {
        setActiveObserver(previousObserver);
      }
    }) as UpdateFn<unknown>
  };

  // Initialize computed value
  updateObserver(o);
  
  const read: GetterFn<T> = () => {
    // Register this computed as a dependency of the active observer
    const currentObserver = getActiveObserver();
    if (currentObserver && currentObserver !== o) {
      // Add current observer to this computed's observers
      observers.add(currentObserver);
      // Add this computed as a dependency of the current observer
      if (!currentObserver.dependencies) {
        currentObserver.dependencies = new Set<Observer<unknown>>();
      }
      currentObserver.dependencies.add(o);
    }
    
    // Return value cast to T
    return o.value as T;
  };

  // Add update function that propagates changes to dependent observers
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (o as any).updateObserver = () => {
    updateObserver(o);
    observers.forEach(observer => updateObserver(observer));
  };

  return read;
}