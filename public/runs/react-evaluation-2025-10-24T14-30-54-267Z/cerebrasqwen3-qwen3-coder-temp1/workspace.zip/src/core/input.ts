/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // If equal is a boolean, use it to determine whether to use strict equality
  const equalFn = (typeof equal === 'function') 
    ? equal 
    : (equal === true) ? (lhs: T, rhs: T) => lhs === rhs : undefined;
  
  // Track all observers that depend on this input
  const observers = new Set<Observer<unknown>>();
  
  const s: Subject<T> = {
    name: options?.name,
    observers,
    value,
    equalFn
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && observer !== s as unknown as Observer<unknown>) {
      observers.add(observer)
      // Also track this input as a dependency of the observer
      if (!observer.dependencies) {
        observer.dependencies = new Set<Observer<unknown>>();
      }
      observer.dependencies.add(s as unknown as Observer<unknown>);
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if the new value is different from current value
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      // Notify all dependent observers
      observers.forEach(observer => {
        // Check if observer has an updateObserver method
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        if ((observer as any).updateObserver) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (observer as any).updateObserver();
        } else {
          updateObserver(observer);
        }
      });
    }
    return s.value;
  };

  return [read, write];
}
