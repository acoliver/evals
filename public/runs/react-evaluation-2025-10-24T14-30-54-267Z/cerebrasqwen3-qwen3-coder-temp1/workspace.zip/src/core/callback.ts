/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies
  let previousObserver: Observer<unknown> | undefined = undefined;
  try {
    previousObserver = setActiveObserver(observer as Observer<unknown>);
    updateObserver(observer);
  } finally {
    setActiveObserver(previousObserver);
  }
  
  let disposed = false;
  
  return () => {
    if (disposed) return;
    disposed = true;
    
    // Clear the observer to stop further updates
    observer.value = undefined as unknown as T;
    observer.updateFn = (): T => undefined as unknown as T;
    
    // Remove this callback from any dependency lists
    if (observer.dependencies) {
      observer.dependencies.forEach((dep) => {
        // Type assertion needed since we can't know the exact type of dep
        const depWithObservers = dep as unknown as { observers?: Set<Observer<unknown>> };
        if (depWithObservers.observers) {
          depWithObservers.observers.delete(observer as Observer<unknown>);
        }
      });
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (observer as any).dependencies = undefined;
    }
  };
}