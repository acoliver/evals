import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';
import type { Application } from 'express';

import { createApp } from '../../src/server';

const dbPath = path.resolve('data', 'submissions.sqlite');

let app: Application;
let db: Database;

async function resetDatabaseFile(): Promise<void> {
  if (fs.existsSync(dbPath)) {
    await fs.promises.unlink(dbPath);
  }
}

beforeAll(async () => {
  await resetDatabaseFile();
  const context = await createApp();
  app = context.app;
  db = context.db;
});

afterAll(async () => {
  if (db) {
    db.close();
  }
  await resetDatabaseFile();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);

    const $ = load(response.text);
    const fieldIds = [
      'firstName',
      'lastName',
      'streetAddress',
      'city',
      'stateProvince',
      'postalCode',
      'country',
      'email',
      'phone',
    ];

    fieldIds.forEach((id) => {
      expect($(`label[for="${id}"]`).length).toBe(1);
      expect($(`#${id}`).length).toBe(1);
    });
  });

  it('stores submissions and redirects to thank-you', async () => {
    const payload = {
      firstName: 'Lupita',
      lastName: 'Fernández',
      streetAddress: '123 Scamstreet',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'lupita@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app).post('/submit').type('form').send(payload);
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you?firstName=Lupita');

    expect(fs.existsSync(dbPath)).toBe(true);

    const SQL = await initSqlJs({
      locateFile: (file: string) => path.resolve('node_modules/sql.js/dist', file),
    });
    const fileBuffer = fs.readFileSync(dbPath);
    const diskDb = new SQL.Database(fileBuffer);
    const result = diskDb.exec('SELECT first_name, email FROM submissions');
    diskDb.close();

    expect(result).toHaveLength(1);
    expect(result[0]?.values).toContainEqual(['Lupita', 'lupita@example.com']);
  });
});
