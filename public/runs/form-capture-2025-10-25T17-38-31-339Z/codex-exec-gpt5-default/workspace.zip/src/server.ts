import express, { type Request, type Response } from 'express';
import type { Server } from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { pathToFileURL } from 'node:url';
import initSqlJs, { type Database, type SqlJsStatic } from 'sql.js';

type FormValues = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

type SubmissionPayload = Partial<Record<keyof FormValues, string | string[]>>;

const templateDir = path.resolve(process.cwd(), 'src', 'templates');
const publicDir = path.resolve(process.cwd(), 'public');
const dataDir = path.resolve(process.cwd(), 'data');
const dbFilePath = path.join(dataDir, 'submissions.sqlite');
const schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');

const formFields: (keyof FormValues)[] = [
  'firstName',
  'lastName',
  'streetAddress',
  'city',
  'stateProvince',
  'postalCode',
  'country',
  'email',
  'phone',
];

const emptyValues: FormValues = formFields.reduce((acc, field) => {
  acc[field] = '';
  return acc;
}, {} as FormValues);

let sqlJsInstance: SqlJsStatic | null = null;

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/i;
const phonePattern = /^\+?[0-9\s().-]{7,30}$/;
const postalPattern = /^[A-Za-z0-9\s-]{3,20}$/;

function ensureDataDirectory(): void {
  fs.mkdirSync(dataDir, { recursive: true });
}

async function getSqlJs(): Promise<SqlJsStatic> {
  if (sqlJsInstance) {
    return sqlJsInstance;
  }

  sqlJsInstance = await initSqlJs({
    locateFile: (file: string) => path.resolve(process.cwd(), 'node_modules', 'sql.js', 'dist', file),
  });

  return sqlJsInstance;
}

function persistDatabase(db: Database): void {
  ensureDataDirectory();
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbFilePath, buffer);
}

async function initializeDatabase(): Promise<Database> {
  ensureDataDirectory();
  const SQL = await getSqlJs();
  let database: Database;

  if (fs.existsSync(dbFilePath)) {
    const fileBuffer = fs.readFileSync(dbFilePath);
    database = new SQL.Database(fileBuffer);
  } else {
    database = new SQL.Database();
  }

  const schema = fs.readFileSync(schemaPath, 'utf-8');
  database.exec(schema);

  if (!fs.existsSync(dbFilePath)) {
    persistDatabase(database);
  }

  return database;
}

function withDefaults(values?: Partial<FormValues>): FormValues {
  return { ...emptyValues, ...(values ?? {}) };
}

function validateSubmission(values: FormValues): string[] {
  const errors: string[] = [];

  for (const field of formFields) {
    if (!values[field] || !values[field].trim()) {
      const label = field.replace(/([A-Z])/g, ' $1').toLowerCase();
      errors.push(`Please provide your ${label.trim()}.`);
    }
  }

  if (values.email && !emailPattern.test(values.email)) {
    errors.push('Email address looks suspicious. Double-check it for us.');
  }

  if (values.phone && !phonePattern.test(values.phone)) {
    errors.push('Phone numbers can use +, spaces, parentheses, and dashes. Yours broke the rules.');
  }

  if (values.postalCode && !postalPattern.test(values.postalCode)) {
    errors.push('Postal codes can mix letters, numbers, spaces, and hyphens — keep it tidy, please.');
  }

  return errors;
}

function normalizePayload(payload: SubmissionPayload): FormValues {
  return formFields.reduce((acc, field) => {
    const rawValue = payload[field];
    if (Array.isArray(rawValue)) {
      acc[field] = rawValue.join(', ').trim();
    } else if (typeof rawValue === 'string') {
      acc[field] = rawValue.trim();
    } else {
      acc[field] = '';
    }
    return acc;
  }, {} as FormValues);
}

function insertSubmission(db: Database, values: FormValues): void {
  const statement = db.prepare(
    `
    INSERT INTO submissions (
      first_name,
      last_name,
      street_address,
      city,
      state_province,
      postal_code,
      country,
      email,
      phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `,
  );

  try {
    statement.bind([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone,
    ]);
    statement.step();
  } finally {
    statement.free();
  }

  persistDatabase(db);
}

function renderForm(res: Response, values?: Partial<FormValues>, errors?: string[], status = 200): void {
  res.status(status).render('form', {
    values: withDefaults(values),
    errors: errors ?? [],
  });
}

function buildApp(db: Database) {
  const app = express();
  app.disable('x-powered-by');
  app.set('view engine', 'ejs');
  app.set('views', templateDir);

  app.use('/public', express.static(publicDir));
  app.use(express.urlencoded({ extended: false }));

  app.get('/', (_req: Request, res: Response) => {
    renderForm(res, emptyValues);
  });

  app.post('/submit', (req: Request, res: Response) => {
    const values = normalizePayload(req.body as SubmissionPayload);
    const errors = validateSubmission(values);

    if (errors.length > 0) {
      renderForm(res, values, errors, 400);
      return;
    }

    try {
      insertSubmission(db, values);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown database error';
      console.error('Failed to store submission:', message);
      renderForm(
        res,
        values,
        ['We could not save your submission. Please refresh and try again.'],
        500,
      );
      return;
    }

    const firstNameParam = encodeURIComponent(values.firstName || 'friend');
    res.redirect(302, `/thank-you?firstName=${firstNameParam}`);
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const { firstName } = req.query;
    const safeFirstName =
      typeof firstName === 'string' && firstName.trim().length > 0 ? firstName.trim() : 'friend';
    res.render('thank-you', { firstName: safeFirstName });
  });

  return app;
}

export interface RunningServer {
  app: ReturnType<typeof buildApp>;
  server: Server;
  close: () => Promise<void>;
  db: Database;
}

export async function createApp(): Promise<{ app: ReturnType<typeof buildApp>; db: Database }> {
  const db = await initializeDatabase();
  const app = buildApp(db);
  return { app, db };
}

export async function startServer(): Promise<RunningServer> {
  const { app, db } = await createApp();
  const port = Number(process.env.PORT ?? 3000);
  const server = app.listen(port, () => {
    console.log(`Friendly form server listening on port ${port}`);
  });

  let closing = false;

  const close = async (): Promise<void> => {
    if (closing) {
      return;
    }
    closing = true;

    await new Promise<void>((resolve) => {
      server.close(() => {
        resolve();
      });
    });

    try {
      persistDatabase(db);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown persistence error';
      console.error('Failed to persist database during shutdown:', message);
    } finally {
      db.close();
    }
  };

  const handleTermination = (): void => {
    void close().catch((error: unknown) => {
      const message = error instanceof Error ? error.message : 'Unknown shutdown error';
      console.error('Failed to close server gracefully:', message);
    });
  };

  process.once('SIGTERM', handleTermination);
  process.once('SIGINT', handleTermination);

  return { app, server, close, db };
}

if (process.argv[1]) {
  const entryUrl = pathToFileURL(process.argv[1]).href;
  if (import.meta.url === entryUrl) {
    void startServer();
  }
}
