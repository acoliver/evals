declare module 'sql.js' {
  export interface Statement {
    bind(values: Array<string | number | null | Uint8Array>): void;
    step(): boolean;
    free(): void;
  }

  export interface Database {
    close(): void;
    exec(sql: string): void;
    export(): Uint8Array;
    prepare(query: string): Statement;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  export interface InitSqlJsConfig {
    locateFile?: (file: string) => string;
  }

  export default function initSqlJs(config?: InitSqlJsConfig): Promise<SqlJsStatic>;
}
