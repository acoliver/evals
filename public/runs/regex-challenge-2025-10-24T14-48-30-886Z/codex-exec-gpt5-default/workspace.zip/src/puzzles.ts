/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\b${escapedPrefix}[\\p{L}\\p{N}_'-]*`, 'giu');
  const disallowed = new Set(exceptions.map((item) => item.toLowerCase()));
  const matches: string[] = [];
  let match: RegExpExecArray | null = null;

  while ((match = pattern.exec(text)) !== null) {
    const candidate = match[0];
    if (!disallowed.has(candidate.toLowerCase())) {
      matches.push(candidate);
    }
  }

  return matches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  const results: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index <= 1) {
      continue;
    }
    const start = match.index - 1;
    results.push(text.slice(start, match.index + token.length));
  }

  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }

  if (/\s/.test(value)) {
    return false;
  }

  const requirements =
    /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[^A-Za-z0-9])[A-Za-z\d\S]+$/u;
  if (!requirements.test(value)) {
    return false;
  }

  const repeatedSequence = /(.{2,})\1/u;
  if (repeatedSequence.test(value)) {
    return false;
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  const ipv6Pattern =
    /\b(?:[A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,7}:\b|\b(?:[A-Fa-f0-9]{1,4}:){1,6}:[A-Fa-f0-9]{1,4}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,5}(?::[A-Fa-f0-9]{1,4}){1,2}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,4}(?::[A-Fa-f0-9]{1,4}){1,3}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,3}(?::[A-Fa-f0-9]{1,4}){1,4}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,2}(?::[A-Fa-f0-9]{1,4}){1,5}\b|\b[A-Fa-f0-9]{1,4}:(?:(?::[A-Fa-f0-9]{1,4}){1,6})\b|\b:(?:(?::[A-Fa-f0-9]{1,4}){1,7}|:)\b|\b(?:[A-Fa-f0-9]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}\b|\b::(?:ffff(?::0{1,4}){0,1}:)?(?:\d{1,3}\.){3}\d{1,3}\b/;

  return ipv6Pattern.test(value);
}
