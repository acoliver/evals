/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return '';
  }

  let normalized = text.replace(/\s+/g, ' ').trim();
  if (!normalized) {
    return '';
  }

  normalized = normalized.replace(/\s+([.!?])/g, '$1');

  const abbreviations = new Set([
    'mr',
    'mrs',
    'ms',
    'dr',
    'prof',
    'sr',
    'jr',
    'st',
    'vs',
    'etc',
    'fig',
    'al',
    'inc',
    'ltd'
  ]);

  normalized = normalized.replace(
    /([.!?])(["')\]]*)(\S)/g,
    (_match, punct: string, closing: string, nextChar: string, offset: number, full: string) => {
      const before = full.slice(0, offset);
      const wordMatch = before.match(/([\p{L}]{1,})$/u);
      const word = wordMatch ? wordMatch[1] : '';
      const lowerWord = word.toLowerCase();
      const isAbbreviation = abbreviations.has(lowerWord) || word.length === 1;
      if (isAbbreviation) {
        return `${punct}${closing}${nextChar}`;
      }
      return `${punct}${closing} ${nextChar}`;
    }
  );

  normalized = normalized.replace(/\s+([.!?])/g, '$1');
  normalized = normalized.replace(/([.!?])\s+/g, '$1 ').trim();

  normalized = normalized.replace(
    /(^|[.!?]\s+)(["'(\[]*)(\p{L})/gu,
    (_, prefix: string, opening: string, letter: string) =>
      `${prefix}${opening}${letter.toLocaleUpperCase()}`
  );

  return normalized;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  const urlRegex = /\bhttps?:\/\/[^\s<>"']+/gi;
  const matches: string[] = [];
  let match: RegExpExecArray | null = null;

  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    while (/[.,!?;:)\]]$/.test(url)) {
      url = url.slice(0, -1);
    }
    matches.push(url);
  }

  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return '';
  }
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return '';
  }

  const rewriteRegex = /http:\/\/example\.com[^\s)"]*/gi;

  return text.replace(rewriteRegex, (raw) => {
    let suffix = '';
    let url = raw;

    while (/[),.;!?\]]$/.test(url)) {
      suffix = url.slice(-1) + suffix;
      url = url.slice(0, -1);
    }

    const pathMatch = url.match(/^http:\/\/example\.com(.*)$/i);
    const path = pathMatch ? pathMatch[1] : '';

    const dynamicPattern = /cgi-bin|\?|&|=|\.jsp\b|\.php\b|\.asp\b|\.aspx\b|\.do\b|\.cgi\b|\.pl\b|\.py\b/i;
    const shouldRewriteHost = path.startsWith('/docs/') && !dynamicPattern.test(path);

    const rewrittenHost = shouldRewriteHost ? 'https://docs.example.com' : 'https://example.com';
    const rewritten = `${rewrittenHost}${path}`;

    return rewritten + suffix;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) {
    return 'N/A';
  }

  const [, monthRaw, dayRaw, yearRaw] = match;
  const month = Number.parseInt(monthRaw, 10);
  const day = Number.parseInt(dayRaw, 10);
  const year = Number.parseInt(yearRaw, 10);

  if (month < 1 || month > 12) {
    return 'N/A';
  }

  const daysInMonth = getDaysInMonth(month, year);
  if (day < 1 || day > daysInMonth) {
    return 'N/A';
  }

  return yearRaw;
}

function getDaysInMonth(month: number, year: number): number {
  const thirtyOneDayMonths = new Set([1, 3, 5, 7, 8, 10, 12]);
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    return isLeapYear ? 29 : 28;
  }
  if (thirtyOneDayMonths.has(month)) {
    return 31;
  }
  return 30;
}
