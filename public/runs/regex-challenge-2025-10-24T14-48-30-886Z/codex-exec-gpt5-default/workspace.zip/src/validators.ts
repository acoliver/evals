export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }
  const trimmed = value.trim();
  if (!trimmed) {
    return false;
  }

  const emailPattern =
    /^(?!.*\.\.)(?:[A-Za-z0-9]+(?:[._%+-][A-Za-z0-9]+)*)@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9]))*(?:\.[A-Za-z]{2,})$/;
  return emailPattern.test(trimmed);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return false;
  }

  const extensionPart = options?.allowExtensions ? '(?:\\s*(?:ext\\.?|x)\\s*\\d+)?' : '';
  const pattern = new RegExp(
    `^\\s*(?:\\+1[\\s.-]*)?` +
      `(?:` +
      `\\(\\s*([2-9][0-9]{2})\\s*\\)[\\s.-]*([2-9][0-9]{2})[\\s.-]*([0-9]{4})` +
      `|` +
      `([2-9][0-9]{2})[\\s.-]*([2-9][0-9]{2})[\\s.-]*([0-9]{4})` +
      `)` +
      `${extensionPart}\\s*$`
  );

  return pattern.test(trimmed);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  const sanitized = value.replace(/[()\s.-]+/g, '');
  if (!sanitized) {
    return false;
  }

  if (!/^\+?\d+$/.test(sanitized)) {
    return false;
  }

  let rest = sanitized;
  let hasCountryCode = false;
  if (rest.startsWith('+')) {
    if (!rest.startsWith('+54')) {
      return false;
    }
    hasCountryCode = true;
    rest = rest.slice(3);
  }

  if (!rest) {
    return false;
  }

  if (hasCountryCode && rest.startsWith('9')) {
    rest = rest.slice(1);
  }

  let hasTrunkPrefix = false;
  if (rest.startsWith('0')) {
    hasTrunkPrefix = true;
    rest = rest.slice(1);
  }

  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }

  for (let areaLength = 2; areaLength <= 4; areaLength += 1) {
    const subscriberLength = rest.length - areaLength;
    if (subscriberLength < 6 || subscriberLength > 8) {
      continue;
    }

    const areaCandidate = rest.slice(0, areaLength);
    if (areaCandidate.startsWith('0')) {
      continue;
    }

    const subscriber = rest.slice(areaLength);
    if (!/^\d+$/.test(subscriber)) {
      continue;
    }

    return true;
  }

  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }
  const trimmed = value.trim();
  if (!trimmed) {
    return false;
  }

  const namePattern = /^[\p{L}]+(?:[’' -][\p{L}]+)*$/u;
  return namePattern.test(trimmed);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  const normalized = value.replace(/[\s-]+/g, '');
  if (!/^\d{13,19}$/.test(normalized)) {
    return false;
  }

  const visaPattern = /^4\d{12}(\d{3}){0,2}$/;
  const amexPattern = /^3[47]\d{13}$/;
  const mastercardPattern =
    /^(?:5[1-5]\d{14}|222[1-9]\d{12}|22[3-9]\d{13}|2[3-6]\d{14}|27[01]\d{13}|2720\d{12})$/;

  const isVisa = visaPattern.test(normalized);
  const isAmex = amexPattern.test(normalized);
  const isMastercard = mastercardPattern.test(normalized);

  if (!isVisa && !isAmex && !isMastercard) {
    return false;
  }

  return runLuhnCheck(normalized);
}

function runLuhnCheck(input: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  for (let i = input.length - 1; i >= 0; i -= 1) {
    let digit = Number.parseInt(input.charAt(i), 10);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
