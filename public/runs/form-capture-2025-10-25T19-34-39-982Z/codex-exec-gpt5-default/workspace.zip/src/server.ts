/// <reference path="./types/sqljs.d.ts" />
import express, { type Express, type Request, type Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import initSqlJs, { type Database, type SqlJsStatic } from 'sql.js';
import type { Server } from 'node:http';

type FormValues = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

type RenderableValues = FormValues;

const __filename = fileURLToPath(import.meta.url);
const currentDir = path.dirname(__filename);
const projectRoot = path.resolve(currentDir, '..');
const dataDir = path.join(projectRoot, 'data');
const dbFilePath = path.join(dataDir, 'submissions.sqlite');
const schemaPath = path.join(projectRoot, 'db', 'schema.sql');
const publicDir = path.join(projectRoot, 'public');
const viewsDir = path.join(projectRoot, 'src', 'templates');
const wasmDir = path.join(projectRoot, 'node_modules', 'sql.js', 'dist');

const sqlJsInstance: Promise<SqlJsStatic> = initSqlJs({
  locateFile: (file: string) => path.join(wasmDir, file)
});

const defaultValues: FormValues = {
  firstName: '',
  lastName: '',
  streetAddress: '',
  city: '',
  stateProvince: '',
  postalCode: '',
  country: '',
  email: '',
  phone: ''
};

const requiredFields: Array<keyof FormValues> = [
  'firstName',
  'lastName',
  'streetAddress',
  'city',
  'stateProvince',
  'postalCode',
  'country',
  'email',
  'phone'
];

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/u;
const phonePattern = /^\+?[0-9\s().-]{7,}$/u;
const postalPattern = /^[A-Za-z0-9\s-]{3,20}$/u;

class SubmissionStore {
  private constructor(private readonly db: Database, private readonly dbPath: string) {}

  static async create(dbPath: string, schemaLocation: string): Promise<SubmissionStore> {
    const SQL = await sqlJsInstance;
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    const dbExists = fs.existsSync(dbPath);
    const dbData = dbExists ? fs.readFileSync(dbPath) : undefined;
    const database = dbData ? new SQL.Database(new Uint8Array(dbData)) : new SQL.Database();
    const schemaSql = fs.readFileSync(schemaLocation, 'utf-8');
    database.run(schemaSql);
    const store = new SubmissionStore(database, dbPath);
    if (!dbExists) {
      store.persist();
    }
    return store;
  }

  insert(values: FormValues): void {
    const stmt = this.db.prepare(
      `
        INSERT INTO submissions (
          first_name,
          last_name,
          street_address,
          city,
          state_province,
          postal_code,
          country,
          email,
          phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `
    );
    stmt.run([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone
    ]);
    stmt.free();
    this.persist();
  }

  private persist(): void {
    const exportBuffer = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(exportBuffer));
  }

  close(): void {
    this.db.close();
  }
}

const buildValues = (source: Partial<Record<keyof FormValues, unknown>>): FormValues => ({
  firstName: String(source.firstName ?? '').trim(),
  lastName: String(source.lastName ?? '').trim(),
  streetAddress: String(source.streetAddress ?? '').trim(),
  city: String(source.city ?? '').trim(),
  stateProvince: String(source.stateProvince ?? '').trim(),
  postalCode: String(source.postalCode ?? '').trim(),
  country: String(source.country ?? '').trim(),
  email: String(source.email ?? '').trim(),
  phone: String(source.phone ?? '').trim()
});

const validate = (values: FormValues): string[] => {
  const errors: string[] = [];
  requiredFields.forEach((field) => {
    if (!values[field]) {
      errors.push(`Please provide your ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}.`);
    }
  });

  if (values.email && !emailPattern.test(values.email)) {
    errors.push('That email address looks suspicious. Try again?');
  }

  if (values.phone) {
    const digitCount = values.phone.replace(/\D/gu, '').length;
    if (!phonePattern.test(values.phone) || digitCount < 6) {
      errors.push('Phone numbers can include +, spaces, and punctuation but must be real-ish.');
    }
  }

  if (values.postalCode && !postalPattern.test(values.postalCode)) {
    errors.push('Postal codes can mix letters, numbers, spaces, and dashes.');
  }

  return errors;
};

const renderForm = (res: Response, values: RenderableValues, errors: string[] = [], status = 200): void => {
  res.status(status).render('form', { errors, values });
};

export type AppContext = {
  app: Express;
  store: SubmissionStore;
  close: () => void;
};

export const createApp = async (): Promise<AppContext> => {
  const store = await SubmissionStore.create(dbFilePath, schemaPath);
  const app = express();

  app.disable('x-powered-by');
  app.set('view engine', 'ejs');
  app.set('views', viewsDir);

  app.use('/public', express.static(publicDir));
  app.use(express.urlencoded({ extended: false }));

  app.get('/', (_req: Request, res: Response) => {
    renderForm(res, defaultValues);
  });

  app.post('/submit', (req: Request, res: Response) => {
    const values = buildValues(req.body as Partial<FormValues>);
    const errors = validate(values);
    if (errors.length > 0) {
      renderForm(res, values, errors, 400);
      return;
    }

    store.insert(values);
    const thankYouLocation = `/thank-you?firstName=${encodeURIComponent(values.firstName)}`;
    res.redirect(302, thankYouLocation);
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const firstNameParam = typeof req.query.firstName === 'string' ? req.query.firstName : '';
    const firstName = firstNameParam.trim() || 'friend';
    res.render('thank-you', { firstName });
  });

  let closed = false;
  const close = (): void => {
    if (closed) {
      return;
    }
    closed = true;
    store.close();
  };

  return { app, store, close };
};

export const startServer = async (): Promise<Server> => {
  const context = await createApp();
  const port = Number(process.env.PORT ?? 3000);
  const server = context.app.listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`Friendly form server listening on port ${port}`);
  });

  const shutdown = (): void => {
    server.close(() => {
      process.exit(0);
    });
  };

  server.on('close', () => {
    context.close();
  });

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  return server;
};

const isDirectRun = (): boolean => {
  const entryPath = process.argv[1];
  if (!entryPath) {
    return false;
  }
  return pathToFileURL(entryPath).href === import.meta.url;
};

if (isDirectRun()) {
  startServer().catch((error: unknown) => {
    // eslint-disable-next-line no-console
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
