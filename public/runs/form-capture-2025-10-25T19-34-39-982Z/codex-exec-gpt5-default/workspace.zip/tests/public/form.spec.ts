import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import initSqlJs from 'sql.js';
import { createApp, type AppContext } from '../../src/server';

const dbPath = path.resolve('data', 'submissions.sqlite');
const fieldNames = [
  'firstName',
  'lastName',
  'streetAddress',
  'city',
  'stateProvince',
  'postalCode',
  'country',
  'email',
  'phone'
];

const runWithApp = async (cb: (context: AppContext) => Promise<void>): Promise<void> => {
  const context = await createApp();
  try {
    await cb(context);
  } finally {
    context.close();
  }
};

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    await runWithApp(async ({ app }) => {
      const response = await request(app).get('/');
      expect(response.status).toBe(200);
      const $ = load(response.text);
      fieldNames.forEach((name) => {
        expect($(`[name="${name}"]`).length).toBeGreaterThan(
          0,
          `Expected to find input with name="${name}"`
        );
      });
      expect($('form').attr('method')).toBe('post');
    });
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    await runWithApp(async ({ app }) => {
      const payload = {
        firstName: 'Ada',
        lastName: 'Lovelace',
        streetAddress: '12 Analytical Engine Road',
        city: 'London',
        stateProvince: 'Greater London',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'ada@example.com',
        phone: '+44 20 7946 0958'
      };

      const response = await request(app).post('/submit').type('form').send(payload);
      expect(response.status).toBe(302);
      expect(response.headers.location).toContain('/thank-you');

      expect(fs.existsSync(dbPath)).toBe(true);

      const SQL = await initSqlJs({
        locateFile: (file) => path.resolve('node_modules', 'sql.js', 'dist', file)
      });
      const raw = fs.readFileSync(dbPath);
      const db = new SQL.Database(new Uint8Array(raw));
      const stmt = db.prepare(
        'SELECT first_name, last_name, email, postal_code FROM submissions ORDER BY id DESC LIMIT 1'
      );
      expect(stmt.step()).toBe(true);
      const row = stmt.getAsObject() as Record<string, string>;
      expect(row.first_name).toBe(payload.firstName);
      expect(row.last_name).toBe(payload.lastName);
      expect(row.email).toBe(payload.email);
      expect(row.postal_code).toBe(payload.postalCode);
      stmt.free();
      db.close();
    });
  });
});
