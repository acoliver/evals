/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  EqualFn,
  GetterFn,
  Options,
  UpdateFn,
  getActiveObserver,
} from '../types/reactive.js'
import {
  TrackedObserver,
  TrackedSubject,
  evaluateObserver,
  normalizeEqualFn,
  notifySubscribers,
  trackDependency,
} from './internal.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options,
): GetterFn<T> {
  const equalFn = normalizeEqualFn(_equal)
  const subject: TrackedSubject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
    subscribers: new Set(),
  }

  let initialized = false

  const observer: TrackedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
    disposed: false,
    onValue: (nextValue: T) => {
      const shouldNotify = initialized ? !equalFn(subject.value, nextValue) : true
      subject.value = nextValue
      initialized = true
      if (shouldNotify) {
        notifySubscribers(subject)
      }
    },
  }

  evaluateObserver(observer)

  const getter: GetterFn<T> = () => {
    trackDependency(subject, getActiveObserver())
    return subject.value
  }

  return getter
}
