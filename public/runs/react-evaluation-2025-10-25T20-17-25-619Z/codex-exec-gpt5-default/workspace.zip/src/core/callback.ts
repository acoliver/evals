/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, UpdateFn } from '../types/reactive.js'
import {
  TrackedObserver,
  disposeObserver,
  evaluateObserver,
} from './internal.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: TrackedObserver<T> = {
    value,
    updateFn,
    dependencies: new Set(),
    disposed: false,
  }

  evaluateObserver(observer)

  return () => disposeObserver(observer)
}
