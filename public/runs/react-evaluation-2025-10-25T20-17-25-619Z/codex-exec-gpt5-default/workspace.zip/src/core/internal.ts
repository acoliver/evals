import {
  EqualFn,
  Observer,
  ObserverR,
  Subject,
  updateObserver,
} from '../types/reactive.js'

export type TrackedSubject<T> = Subject<T> & {
  equalFn: EqualFn<T>
  subscribers: Set<TrackedObserver<unknown>>
}

export type TrackedObserver<T> = Observer<T> & {
  dependencies: Set<TrackedSubject<unknown>>
  disposed: boolean
  onValue?: (next: T, previous: T | undefined) => void
}

export function normalizeEqualFn<T>(
  equal?: boolean | EqualFn<T>,
): EqualFn<T> {
  if (typeof equal === 'function') return equal
  if (equal === false) return () => false
  return Object.is
}

function isTrackedObserver(observer?: ObserverR): observer is TrackedObserver<unknown> {
  if (!observer || typeof observer !== 'object') return false
  const candidate = observer as TrackedObserver<unknown>
  return candidate.dependencies instanceof Set && typeof candidate.disposed === 'boolean'
}

export function trackDependency<T>(
  subject: TrackedSubject<T>,
  observerLike?: ObserverR,
): void {
  if (!observerLike) return
  if (!isTrackedObserver(observerLike)) return
  if (observerLike.disposed) return
  subject.subscribers.add(observerLike)
  observerLike.dependencies.add(subject as TrackedSubject<unknown>)
}

export function cleanupObserver<T>(observer: TrackedObserver<T>): void {
  if (!observer.dependencies.size) return
  for (const subject of observer.dependencies) {
    subject.subscribers.delete(observer as TrackedObserver<unknown>)
  }
  observer.dependencies.clear()
}

export function evaluateObserver<T>(observer: TrackedObserver<T>): void {
  if (observer.disposed) return
  const previousValue = observer.value as T | undefined
  cleanupObserver(observer)
  updateObserver(observer)
  observer.onValue?.(observer.value as T, previousValue)
}

export function notifySubscribers<T>(subject: TrackedSubject<T>): void {
  if (!subject.subscribers.size) return
  const observers = Array.from(subject.subscribers)
  for (const observer of observers) {
    evaluateObserver(observer as TrackedObserver<unknown>)
  }
}

export function disposeObserver<T>(observer: TrackedObserver<T>): void {
  if (observer.disposed) return
  observer.disposed = true
  cleanupObserver(observer)
  observer.value = undefined
  observer.onValue = undefined
}
