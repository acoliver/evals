/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  getActiveObserver,
} from '../types/reactive.js'
import {
  normalizeEqualFn,
  notifySubscribers,
  trackDependency,
  TrackedSubject,
} from './internal.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: TrackedSubject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: normalizeEqualFn(_equal),
    subscribers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    trackDependency(subject, observer)
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (subject.equalFn(subject.value, nextValue)) return subject.value
    subject.value = nextValue
    notifySubscribers(subject)
    return subject.value
  }

  return [read, write]
}
