import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      const pageValue = Number(pageParam);
      if (isNaN(pageValue) || pageValue <= 0 || !Number.isInteger(pageValue)) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
      }
      page = pageValue;
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      const limitValue = Number(limitParam);
      if (isNaN(limitValue) || limitValue <= 0 || limitValue > 100 || !Number.isInteger(limitValue)) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer not exceeding 100.' });
      }
      limit = limitValue;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
