export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value) {
    return false;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return false;
  }

  const emailRegex =
    /^(?!.*\.\.)(?!.*\.$)(?!^\.)[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/;

  return emailRegex.test(trimmed);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value) {
    return false;
  }

  const extensionPattern = /\s*(?:ext\.?|extension|x)\s*\d{1,6}$/i;
  let normalized = value.trim();

  if (!normalized) {
    return false;
  }

  if (options?.allowExtensions) {
    normalized = normalized.replace(extensionPattern, '').trim();
  } else if (extensionPattern.test(normalized)) {
    return false;
  }

  const structurePattern =
    /^(?:\+?1[\s.-]*)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))[\s.-]*\d{3}[\s.-]*\d{4}$/;

  if (!structurePattern.test(normalized)) {
    return false;
  }

  let digits = normalized.replace(/\D/g, '');
  if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.slice(1);
  }

  if (digits.length !== 10) {
    return false;
  }

  return /^[2-9]\d{2}\d{7}$/.test(digits);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) {
    return false;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return false;
  }

  const cleaned = trimmed.replace(/[\s()-]/g, '');
  if (!cleaned) {
    return false;
  }

  let remaining = cleaned;
  let hasCountryCode = false;

  if (remaining.startsWith('+')) {
    if (!remaining.startsWith('+54')) {
      return false;
    }
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }

  if (!remaining) {
    return false;
  }

  if (hasCountryCode) {
    if (remaining.startsWith('0')) {
      remaining = remaining.slice(1);
    }
  } else {
    if (!remaining.startsWith('0')) {
      return false;
    }
    remaining = remaining.slice(1);
  }

  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }

  const areaMatch = remaining.match(/^([1-9]\d{1,3})/);
  if (!areaMatch) {
    return false;
  }

  const areaCode = areaMatch[1];
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  const subscriber = remaining.slice(areaCode.length);
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }

  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value) {
    return false;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return false;
  }

  const allowedCharacters = /^[\p{L}\p{M}'’\- ]+$/u;
  if (!allowedCharacters.test(trimmed)) {
    return false;
  }

  const startsWithLetter = /^\p{L}/u.test(trimmed);
  const endsWithLetter = /\p{L}$/u.test(trimmed);

  return startsWithLetter && endsWithLetter;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) {
    return false;
  }

  const digitsOnly = value.replace(/[\s-]/g, '');
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }

  const length = digitsOnly.length;
  const firstTwo = Number(digitsOnly.slice(0, 2));
  const firstFour = Number(digitsOnly.slice(0, 4));

  const isVisa = digitsOnly.startsWith('4') && [13, 16, 19].includes(length);
  const isMastercard =
    length === 16 &&
    ((firstTwo >= 51 && firstTwo <= 55) || (firstFour >= 2221 && firstFour <= 2720));
  const isAmex = /^3[47]\d{13}$/.test(digitsOnly);

  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }

  return runLuhnCheck(digitsOnly);
}

function runLuhnCheck(sequence: string): boolean {
  let sum = 0;
  let doubleDigit = false;

  for (let i = sequence.length - 1; i >= 0; i -= 1) {
    let digit = Number(sequence[i]);

    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    doubleDigit = !doubleDigit;
  }

  return sum % 10 === 0;
}
