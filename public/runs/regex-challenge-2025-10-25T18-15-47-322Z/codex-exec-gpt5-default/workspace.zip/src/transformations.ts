/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return '';
  }

  const working = text.replace(/\s+/g, ' ').trim();
  if (!working) {
    return '';
  }

  let result = '';
  let shouldCapitalize = true;
  let pendingSpace = false;

  for (let i = 0; i < working.length; i += 1) {
    const char = working[i];

    if (char === ' ') {
      pendingSpace = true;
      continue;
    }

    if (isSentenceEnd(working, i)) {
      result += char;
      shouldCapitalize = true;
      pendingSpace = true;
      continue;
    }

    if (pendingSpace && result.length) {
      result += ' ';
      pendingSpace = false;
    } else {
      pendingSpace = false;
    }

    if (shouldCapitalize && isLetter(char)) {
      result += char.toUpperCase();
      shouldCapitalize = false;
      continue;
    }

    result += char;
    if (isLetter(char) || /\d/.test(char)) {
      shouldCapitalize = false;
    }
  }

  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  const urlRegex = /https?:\/\/[^\s<>"')]+/gi;
  const matches: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = urlRegex.exec(text)) !== null) {
    const rawUrl = match[0];
    matches.push(trimTrailingPunctuation(rawUrl));
  }

  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return '';
  }

  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return '';
  }

  const docsRegex = /http:\/\/example\.com([^\s<>"')]*)/gi;
  return text.replace(docsRegex, (_, path: string) => {
    const safePath = path || '';
    const needsDocsHost =
      safePath.startsWith('/docs/') && !hasDynamicHint(safePath);

    const baseHost = needsDocsHost ? 'https://docs.example.com' : 'https://example.com';
    return `${baseHost}${safePath}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) {
    return 'N/A';
  }

  const [, monthText, dayText, year] = match;
  const month = Number(monthText);
  const day = Number(dayText);

  if (month < 1 || month > 12) {
    return 'N/A';
  }

  const daysInMonth = getDaysInMonth(month, Number(year));
  if (day < 1 || day > daysInMonth) {
    return 'N/A';
  }

  return year;
}

function trimTrailingPunctuation(url: string): string {
  return url.replace(/[)\],.;!?'"}>]+$/g, '');
}

function hasDynamicHint(path: string): boolean {
  const dynamicPatterns = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
  if (/[?&=]/.test(path)) {
    return true;
  }
  return dynamicPatterns.some((hint) => path.toLowerCase().includes(hint));
}

function getDaysInMonth(month: number, year: number): number {
  const monthLengths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (month === 2 && isLeapYear(year)) {
    return 29;
  }
  return monthLengths[month - 1];
}

function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

function isSentenceEnd(text: string, index: number): boolean {
  const char = text[index];
  if (!/[.?!]/.test(char)) {
    return false;
  }

  if (char === '.' && (isDecimalPoint(text, index) || isAbbreviationDot(text, index))) {
    return false;
  }

  return true;
}

function isDecimalPoint(text: string, index: number): boolean {
  const prev = text[index - 1];
  const next = text[index + 1];
  return Boolean(prev && next && /\d/.test(prev) && /\d/.test(next));
}

function isAbbreviationDot(text: string, index: number): boolean {
  if (text[index] !== '.') {
    return false;
  }

  const prev = text[index - 1];
  const next = text[index + 1];
  const following = text[index + 2];

  if (!prev || !next || !/[A-Za-z]/.test(prev) || !/[A-Za-z]/.test(next)) {
    return false;
  }

  return following === '.';
}

function isLetter(char: string): boolean {
  return /\p{L}/u.test(char);
}
