/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  const escapedPrefix = escapeForRegex(prefix);
  const regex = new RegExp(`\\b${escapedPrefix}[\\p{L}\\p{M}'-]*\\b`, 'giu');
  const banned = new Set(exceptions.map((item) => item.toLowerCase()));
  const matches: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    const word = match[0];
    if (!banned.has(word.toLowerCase())) {
      matches.push(word);
    }
  }

  return matches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  const escapedToken = escapeForRegex(token);
  const regex = new RegExp(`(?<=.)\\d${escapedToken}`, 'g');
  const results: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    results.push(match[0]);
  }

  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10 || /\s/.test(value)) {
    return false;
  }

  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);

  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }

  if (/(.{2,})\1/.test(value)) {
    return false;
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  const h16 = '[A-Fa-f0-9]{1,4}';
  const decOctet = '(?:25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)';
  const ipv4Address = `(?:${decOctet}\\.){3}${decOctet}`;
  const ls32 = `(?:${h16}:${h16}|${ipv4Address})`;

  const pattern = new RegExp(
    `(?<![A-Fa-f0-9:])(?:` +
      `(?:${h16}:){7}${h16}|` +
      `(?:${h16}:){1,7}:|` +
      `(?:${h16}:){1,6}:${h16}|` +
      `(?:${h16}:){1,5}(?::${h16}){1,2}|` +
      `(?:${h16}:){1,4}(?::${h16}){1,3}|` +
      `(?:${h16}:){1,3}(?::${h16}){1,4}|` +
      `(?:${h16}:){1,2}(?::${h16}){1,5}|` +
      `${h16}:(?::${h16}){1,6}|` +
      `:(?::${h16}){1,7}|` +
      `::|` +
      `(?:${h16}:){6}${ls32}|` +
      `(?:${h16}:){1,5}:(?:${ls32})|` +
      `(?:${h16}:){1,4}(?::${h16})?:(?:${ls32})|` +
      `(?:${h16}:){1,3}(?::${h16}){0,2}:(?:${ls32})|` +
      `(?:${h16}:){1,2}(?::${h16}){0,3}:(?:${ls32})|` +
      `${h16}:(?::${h16}){0,4}:(?:${ls32})|` +
      `:(?::${h16}){0,5}:(?:${ls32})` +
      `)(?![A-Fa-f0-9:])`,
    'g'
  );

  return pattern.test(value);
}

function escapeForRegex(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
