#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);
let dataFile: string | undefined;
let format: string | undefined;
let outputFile: string | undefined;
let includeTotals = false;

for (let i = 0; i < args.length; i++) {
  switch (args[i]) {
    case '--format':
      format = args[++i];
      break;
    case '--output':
      outputFile = args[++i];
      break;
    case '--includeTotals':
      includeTotals = true;
      break;
    default:
      if (!dataFile) {
        dataFile = args[i];
      }
      break;
  }
}

// Validate required arguments
if (!dataFile) {
  console.error('Error: Data file is required');
  process.exit(1);
}

if (!format) {
  console.error('Error: --format is required');
  process.exit(1);
}

// Validate format
if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format '${format}'`);
  process.exit(1);
}

// Read and parse data file
let data: ReportData;
try {
  const fileContent = readFileSync(dataFile, 'utf-8');
  data = JSON.parse(fileContent);
  
  // Validate data structure
  if (!data.title || !data.summary || !Array.isArray(data.entries)) {
    throw new Error('Invalid data structure');
  }
  
  for (const entry of data.entries) {
    if (!entry.label || typeof entry.amount !== 'number') {
      throw new Error('Invalid entry structure');
    }
  }
} catch (error) {
  console.error(`Error reading or parsing data file: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}

// Render report based on format
let output: string;
switch (format) {
  case 'markdown':
    output = renderMarkdown(data, { includeTotals });
    break;
  case 'text':
    output = renderText(data, { includeTotals });
    break;
  default:
    console.error(`Error: Unsupported format '${format}'`);
    process.exit(1);
}

// Write to output file or stdout
if (outputFile) {
  writeFileSync(outputFile, output);
} else {
  console.log(output);
}