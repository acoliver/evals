# Report Formats

This directory contains modules for rendering reports in different formats.

Each format module exports a function that takes report data and options, and returns a string representation of the report.

To add a new format:
1. Create a new TypeScript file in this directory
2. Export a function that matches the signature of the existing format functions
3. Add the format to the format map in the CLI