const BASE64_BODY = /^[A-Za-z0-9+/]*$/;

const ERROR_INVALID_BASE64 = 'Failed to decode Base64 input';

const PAD_LENGTH = 4;

/**
 * Encode plain text to canonical RFC 4648 Base64.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts inputs with or without padding while rejecting clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (trimmed === '') {
    return '';
  }

  if (!isValidBase64(trimmed)) {
    throw new Error(ERROR_INVALID_BASE64);
  }

  const normalized = addMissingPadding(trimmed);

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error(ERROR_INVALID_BASE64);
  }
}

function isValidBase64(value: string): boolean {
  if (value.length % PAD_LENGTH === 1) {
    return false;
  }

  const paddingIndex = value.indexOf('=');
  const body = paddingIndex === -1 ? value : value.slice(0, paddingIndex);
  const padding = paddingIndex === -1 ? '' : value.slice(paddingIndex);

  if (!BASE64_BODY.test(body)) {
    return false;
  }

  if (padding === '') {
    return true;
  }

  if (padding.length > 2 || /[^=]/.test(padding)) {
    return false;
  }

  if (value.length % PAD_LENGTH !== 0) {
    return false;
  }

  const bodyRemainder = body.length % PAD_LENGTH;
  if (padding.length === 1 && bodyRemainder !== PAD_LENGTH - 1) {
    return false;
  }

  if (padding.length === 2 && bodyRemainder !== PAD_LENGTH - 2) {
    return false;
  }

  return true;
}

function addMissingPadding(value: string): string {
  const remainder = value.length % PAD_LENGTH;
  if (remainder === 0) {
    return value;
  }

  const paddingLength = PAD_LENGTH - remainder;
  return `${value}${'='.repeat(paddingLength)}`;
}
