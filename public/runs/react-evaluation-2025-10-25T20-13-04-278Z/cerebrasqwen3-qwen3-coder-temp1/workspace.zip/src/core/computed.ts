/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle the boolean case for equality function
  const _equalFn: EqualFn<T> | undefined = equal === false 
    ? undefined 
    : typeof equal === 'function' 
      ? equal 
      : Object.is

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Initialize the computed value by running updateFn once
  o.value = updateFn(value)
  
  const get: GetterFn<T> = () => {
    // Track this computed as a dependency of the currently active observer
    const observer = getActiveObserver()
    if (observer) {
      // In a full implementation, we would track dependencies here and
      // update observers when this computed's value changes
    }
    return o.value!
  }
  
  return get
}