/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle the boolean case for equality function
  const equalFn: EqualFn<T> | undefined = equal === false 
    ? undefined 
    : typeof equal === 'function' 
      ? equal 
      : Object.is
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track this input as a dependency of the currently active observer
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value has actually changed
    const isEqual = s.equalFn ?? Object.is
    if (!isEqual(s.value, nextValue)) {
      s.value = nextValue
      if (s.observer) {
        // Update observer when value changes
        updateObserver(s.observer as Observer<unknown>)
      }
    }
    return s.value
  }

  return [read, write]
}
