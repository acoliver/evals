export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface PreparedReport extends ReportData {
  total: number;
}

export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Validate the raw JSON payload and coerce it into the expected report shape.
 */
export function parseReportData(payload: unknown): ReportData {
  if (payload === null || typeof payload !== 'object') {
    throw new Error('Report JSON must be an object.');
  }

  const { title, summary, entries } = payload as {
    title?: unknown;
    summary?: unknown;
    entries?: unknown;
  };

  if (typeof title !== 'string' || title.trim() === '') {
    throw new Error('Report requires a string title.');
  }

  if (typeof summary !== 'string' || summary.trim() === '') {
    throw new Error('Report requires a string summary.');
  }

  if (!Array.isArray(entries)) {
    throw new Error('Report entries must be an array.');
  }

  const parsedEntries = entries.map((entry, index) => {
    if (entry === null || typeof entry !== 'object') {
      throw new Error(`Entry at index ${index} must be an object.`);
    }

    const { label, amount } = entry as {
      label?: unknown;
      amount?: unknown;
    };

    if (typeof label !== 'string' || label.trim() === '') {
      throw new Error(`Entry at index ${index} requires a string label.`);
    }

    if (typeof amount !== 'number' || !Number.isFinite(amount)) {
      throw new Error(`Entry at index ${index} requires a finite numeric amount.`);
    }

    return {
      label,
      amount,
    };
  });

  return {
    title,
    summary,
    entries: parsedEntries,
  };
}

export function prepareReport(data: ReportData): PreparedReport {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  return {
    ...data,
    total,
  };
}

export function formatAmount(value: number): string {
  return `$${value.toFixed(2)}`;
}
