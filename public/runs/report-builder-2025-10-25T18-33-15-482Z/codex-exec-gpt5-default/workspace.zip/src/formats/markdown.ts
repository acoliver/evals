import { formatAmount, PreparedReport, RenderOptions } from '../report.js';

export function renderMarkdown(report: PreparedReport, options: RenderOptions): string {
  const lines = [
    `# ${report.title}`,
    '',
    report.summary,
    '',
    '## Entries',
    ...report.entries.map(
      (entry) => `- **${entry.label}** — ${formatAmount(entry.amount)}`,
    ),
  ];

  if (options.includeTotals) {
    lines.push('', `**Total:** ${formatAmount(report.total)}`);
  }

  return ensureTrailingNewline(lines.join('\n'));
}

function ensureTrailingNewline(text: string): string {
  return text.endsWith('\n') ? text : `${text}\n`;
}
