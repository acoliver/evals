#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import {
  parseReportData,
  prepareReport,
  PreparedReport,
  RenderOptions,
} from '../report.js';

type Formatter = (report: PreparedReport, options: RenderOptions) => string;

const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

try {
  const args = parseArgs(process.argv.slice(2));
  const formatter = formatters[args.format];

  if (!formatter) {
    throw new Error(`Unsupported format: ${args.format}`);
  }

  const report = loadReport(args.dataPath);
  const output = formatter(report, { includeTotals: args.includeTotals });

  if (args.outputPath) {
    const resolvedOutput = path.resolve(process.cwd(), args.outputPath);
    writeFileSync(resolvedOutput, output, 'utf8');
  } else {
    process.stdout.write(output);
  }
} catch (error) {
  handleFatalError(error);
}

function parseArgs(argv: string[]): CliArgs {
  let dataPath: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];

    if (arg === '--includeTotals') {
      includeTotals = true;
      continue;
    }

    if (arg === '--format') {
      const value = argv[i + 1];
      if (!value) {
        throw new Error('Missing value for --format option.');
      }
      format = value.toLowerCase();
      i += 1;
      continue;
    }

    if (arg.startsWith('--format=')) {
      format = arg.slice('--format='.length).toLowerCase();
      continue;
    }

    if (arg === '--output') {
      const value = argv[i + 1];
      if (!value) {
        throw new Error('Missing value for --output option.');
      }
      outputPath = value;
      i += 1;
      continue;
    }

    if (arg.startsWith('--output=')) {
      outputPath = arg.slice('--output='.length);
      continue;
    }

    if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    }

    if (!dataPath) {
      dataPath = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!dataPath) {
    throw new Error('Missing path to data JSON.');
  }

  if (!format) {
    throw new Error('Missing --format option.');
  }

  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

function loadReport(dataPath: string): PreparedReport {
  const resolvedPath = path.resolve(process.cwd(), dataPath);
  let rawContent: string;

  try {
    rawContent = readFileSync(resolvedPath, 'utf8');
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Unable to read data file "${dataPath}": ${message}`);
  }

  let parsedJson: unknown;
  try {
    parsedJson = JSON.parse(rawContent);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to parse JSON from "${dataPath}": ${message}`);
  }

  const data = parseReportData(parsedJson);
  return prepareReport(data);
}

function handleFatalError(error: unknown): never {
  const message = error instanceof Error ? error.message : String(error);
  console.error(message);
  process.exit(1);
}
